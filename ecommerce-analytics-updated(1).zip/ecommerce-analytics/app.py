from pathlib import Path
import io
import pandas as pd
import plotly.express as px
import streamlit as st
from src.data_loader import load_csv, generate_sample_data, COLUMNS
from src.generic_analytics import profile_data, clean_generic, filter_generic
from src.data_cleaning import clean_data
from src.database import initialize_database, query_df
from src.analytics import add_metrics, completed_sales, kpis, monthly_revenue, group_revenue, order_status_summary, customer_rfm, business_insights

st.set_page_config(page_title="E-Commerce Analytics", page_icon="📊", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.5rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {background: linear-gradient(135deg,#f7f9fc,#edf4ff); border: 1px solid #dce6f5; padding: 14px 16px; border-radius: 12px;}
[data-testid="stSidebar"] {background: #f6f8fc;}
</style>
""", unsafe_allow_html=True)

st.title("📊 E-Commerce Sales & Customer Analytics")
st.caption("Interactive business intelligence mini-project • Sample records are simulated, not real company transactions.")

with st.sidebar:
    st.header("Data & Filters")
    uploaded = st.file_uploader("Upload your own CSV", type=["csv"])
    st.caption("Expected columns are listed in the README. If no file is uploaded, the included sample dataset is used.")

# Use the default sample when no CSV has been uploaded. For unrelated CSVs,
# show generic analytics instead of inventing e-commerce metrics.
try:
    raw = load_csv(uploaded)
except (ValueError, UnicodeError, pd.errors.ParserError, OSError) as exc:
    st.error(f"Unable to read CSV: {exc}")
    st.stop()
if raw.empty or len(raw.columns) == 0:
    st.error("The CSV is empty. Upload a CSV with column headers and data rows.")
    st.stop()

with st.sidebar:
    st.caption(f"Active dataset: {uploaded.name if uploaded is not None else 'Included sample dataset'}")

is_ecommerce = all(c in raw.columns for c in COLUMNS)
if not is_ecommerce:
    st.subheader("📁 General CSV Analytics")
    st.info("This file does not have the complete e-commerce schema. Showing general data analysis; sales KPIs are disabled.")
    st.caption(f"File: {uploaded.name if uploaded is not None else 'Sample'} | Rows: {len(raw):,} | Columns: {len(raw.columns)}")
    try:
        profile, duplicates = profile_data(raw)
    except ValueError as exc:
        st.error(str(exc))
        st.stop()
    a, b, c = st.columns(3)
    a.metric("Rows", f"{len(raw):,}")
    b.metric("Columns", len(raw.columns))
    c.metric("Duplicate rows", duplicates)
    with st.expander("Raw data preview", expanded=True):
        st.dataframe(raw.head(100), use_container_width=True)
    st.markdown("### Data quality and types")
    st.dataframe(profile, use_container_width=True, hide_index=True)
    cleaned_generic = clean_generic(raw)
    st.caption(f"Cleaned data: {len(cleaned_generic):,} rows (exact duplicates removed; text trimmed). Missing values are preserved.")
    st.download_button("Download cleaned CSV", cleaned_generic.to_csv(index=False).encode('utf-8-sig'), "cleaned_uploaded_data.csv", "text/csv")
    st.markdown("### Interactive filters")
    selections = {}
    eligible = [col for col in cleaned_generic.columns if 1 < cleaned_generic[col].nunique(dropna=True) <= 50]
    for col in st.multiselect("Columns to filter", eligible, default=[]):
        options = sorted(cleaned_generic[col].dropna().astype(str).unique().tolist())
        selections[col] = st.multiselect(f"{col} values", options, default=options, key=f"generic_{col}")
    view = filter_generic(cleaned_generic, selections)
    st.caption(f"Filtered records: {len(view):,}")
    st.dataframe(view.head(1000), use_container_width=True)
    st.download_button("Download filtered CSV", view.to_csv(index=False).encode('utf-8-sig'), "filtered_uploaded_data.csv", "text/csv")
    if not view.empty:
        st.markdown("### Explore your data")
        numerical = view.select_dtypes(include='number').columns.tolist()
        categorical = [col for col in view.columns if 1 < view[col].nunique(dropna=True) <= 50]
        if numerical:
            st.markdown("#### Numeric summary")
            st.dataframe(view[numerical].describe().T, use_container_width=True)
            measure = st.selectbox("Numeric column", numerical)
            st.plotly_chart(px.histogram(view, x=measure, title=f"Distribution of {measure}"), use_container_width=True)
        if categorical:
            category = st.selectbox("Category column", categorical)
            counts = view[category].astype('string').fillna('Missing').value_counts().head(20).reset_index()
            counts.columns = [category, 'Count']
            st.plotly_chart(px.bar(counts, x=category, y='Count', title=f"Top values: {category}"), use_container_width=True)
    st.stop()

try:
    raw = load_csv(uploaded)
except Exception as e:
    st.error(f"Could not read the dataset: {e}")
    st.stop()
cleaned, quality_report = clean_data(raw)
if cleaned.empty:
    st.error("No valid rows remain after cleaning. Please upload a CSV with valid dates, positive prices and quantities, and discounts between 0 and 1.")
    st.stop()

# Build the local database from the currently cleaned data.
try:
    initialize_database(cleaned)
except Exception as e:
    st.warning(f"SQLite database could not be refreshed: {e}")

cleaned = add_metrics(cleaned)
cleaned["Order_Date"] = pd.to_datetime(cleaned["Order_Date"])
with st.sidebar:
    min_date = cleaned["Order_Date"].min().date()
    max_date = cleaned["Order_Date"].max().date()
    date_range = st.date_input("Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
    categories = sorted(cleaned["Category"].dropna().unique().tolist())
    selected_categories = st.multiselect("Category", categories, default=categories)
    cities = sorted(cleaned["City"].dropna().unique().tolist())
    selected_cities = st.multiselect("City", cities, default=cities)
    states = sorted(cleaned["State"].dropna().unique().tolist())
    selected_states = st.multiselect("State", states, default=states)
    methods = sorted(cleaned["Payment_Method"].dropna().unique().tolist())
    selected_methods = st.multiselect("Payment method", methods, default=methods)
    statuses = sorted(cleaned["Order_Status"].dropna().unique().tolist())
    selected_statuses = st.multiselect("Order status", statuses, default=statuses)
    genders = sorted(cleaned["Gender"].dropna().unique().tolist())
    selected_genders = st.multiselect("Gender", genders, default=genders)

if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start_date, end_date = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1]) + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
else:
    start_date, end_date = pd.Timestamp(min_date), pd.Timestamp(max_date) + pd.Timedelta(days=1)
filtered = cleaned[(cleaned["Order_Date"] >= start_date) & (cleaned["Order_Date"] <= end_date)]
for col, vals in [("Category", selected_categories), ("City", selected_cities), ("State", selected_states), ("Payment_Method", selected_methods), ("Order_Status", selected_statuses), ("Gender", selected_genders)]:
    filtered = filtered[filtered[col].isin(vals)]

pages = ["Executive Overview", "Sales Analytics", "Customer Analytics", "Product Analytics", "Data Explorer", "Business Insights", "SQL Explorer"]
page = st.sidebar.radio("Navigate", pages)
if filtered.empty:
    st.warning("No records match the selected filters. Adjust the sidebar filters.")
    st.stop()

if page == "Executive Overview":
    st.subheader("Executive Overview")
    k = kpis(filtered)
    cols = st.columns(4)
    cols[0].metric("Net Revenue", f"₹{k['revenue']:,.0f}")
    cols[1].metric("Orders", f"{k['orders']:,}")
    cols[2].metric("Units Sold", f"{k['units']:,}")
    cols[3].metric("Average Order Value", f"₹{k['aov']:,.0f}")
    cols2 = st.columns(4)
    cols2[0].metric("Customers", f"{k['customers']:,}")
    cols2[1].metric("Average Discount", f"{k['avg_discount']:.1f}%")
    cols2[2].metric("Repeat Customer Rate", f"{k['repeat_rate']:.1f}%")
    cols2[3].metric("Month-over-Month", "N/A" if k["mom_growth"] is None else f"{k['mom_growth']:+.1f}%")
    left, right = st.columns(2)
    m = monthly_revenue(filtered)
    if not m.empty: left.plotly_chart(px.line(m, x="Month", y="Revenue", markers=True, title="Monthly Net Revenue", template="plotly_white"), use_container_width=True)
    cat = group_revenue(filtered, "Category")
    if not cat.empty: right.plotly_chart(px.bar(cat, x="Category", y="Revenue", title="Revenue by Category", template="plotly_white", color="Category"), use_container_width=True)
    st.markdown("#### Top products")
    st.dataframe(group_revenue(filtered, "Product_Name").head(10), use_container_width=True, hide_index=True)
    st.markdown("#### Recent orders")
    st.dataframe(filtered.sort_values("Order_Date", ascending=False)[["Order_ID", "Order_Date", "Customer_ID", "Product_Name", "Category", "Quantity", "Net_Revenue", "Order_Status"]].head(12), use_container_width=True, hide_index=True)

elif page == "Sales Analytics":
    st.subheader("Sales Analytics")
    m = monthly_revenue(filtered)
    a, b = st.columns(2)
    if not m.empty: a.plotly_chart(px.line(m, x="Month", y="Revenue", markers=True, title="Revenue Trend", template="plotly_white"), use_container_width=True)
    by_city = group_revenue(filtered, "City")
    if not by_city.empty: b.plotly_chart(px.bar(by_city, x="City", y="Revenue", title="Revenue by City", template="plotly_white"), use_container_width=True)
    c, d = st.columns(2)
    status = order_status_summary(filtered)
    c.plotly_chart(px.pie(status, names="Order_Status", values="Orders", hole=.45, title="Order Status Distribution"), use_container_width=True)
    sales = completed_sales(filtered)
    if not sales.empty: d.plotly_chart(px.histogram(sales.groupby("Order_ID", as_index=False)["Net_Revenue"].sum(), x="Net_Revenue", nbins=25, title="Order Value Distribution"), use_container_width=True)
    st.markdown("#### Category and city performance")
    st.dataframe(cat if 'cat' in locals() else group_revenue(filtered, "Category"), use_container_width=True, hide_index=True)
    st.dataframe(by_city, use_container_width=True, hide_index=True)

elif page == "Customer Analytics":
    st.subheader("Customer Analytics")
    sales = completed_sales(filtered)
    if sales.empty:
        st.info("No completed or shipped sales for customer analysis.")
    else:
        cust = sales.groupby(["Customer_ID", "Customer_Name"], as_index=False).agg(Orders=("Order_ID", "nunique"), Spending=("Net_Revenue", "sum"), Units=("Quantity", "sum"))
        cust["Customer Type"] = cust["Orders"].map(lambda x: "Repeat" if x > 1 else "One-time")
        a, b = st.columns(2)
        a.plotly_chart(px.histogram(cust, x="Orders", nbins=20, title="Completed Orders per Customer"), use_container_width=True)
        b.plotly_chart(px.pie(cust, names="Customer Type", title="One-time vs Repeat Customers", hole=.4), use_container_width=True)
        st.markdown("#### Highest-spending customers")
        st.dataframe(cust.sort_values("Spending", ascending=False).head(10), use_container_width=True, hide_index=True)
        st.markdown("#### RFM customer segmentation")
        rfm = customer_rfm(filtered)
        st.caption("RFM segments use transparent rank-based demonstration rules and should be calibrated before real business use.")
        x, y = st.columns(2)
        x.plotly_chart(px.bar(rfm["Segment"].value_counts().rename_axis("Segment").reset_index(name="Customers"), x="Segment", y="Customers", title="Customers by RFM Segment"), use_container_width=True)
        y.dataframe(rfm.head(30), use_container_width=True, hide_index=True)
        st.download_button("Download RFM report", rfm.to_csv(index=False).encode("utf-8"), "customer_rfm_report.csv", "text/csv")

elif page == "Product Analytics":
    st.subheader("Product Analytics")
    prod = group_revenue(filtered, "Product_Name")
    a, b = st.columns(2)
    a.plotly_chart(px.bar(prod.head(10), x="Product_Name", y="Revenue", title="Top 10 Products by Revenue", template="plotly_white"), use_container_width=True)
    b.plotly_chart(px.bar(prod.sort_values("Units", ascending=False).head(10), x="Product_Name", y="Units", title="Top 10 Products by Units Sold", template="plotly_white"), use_container_width=True)
    sales = completed_sales(filtered)
    if not sales.empty: st.plotly_chart(px.scatter(sales, x="Quantity", y="Net_Revenue", color="Category", hover_data=["Product_Name", "Order_ID"], title="Quantity vs Net Revenue"), use_container_width=True)
    st.dataframe(prod, use_container_width=True, hide_index=True)

elif page == "Data Explorer":
    st.subheader("Data Explorer")
    tab1, tab2, tab3 = st.tabs(["Filtered data", "Data quality", "Downloads"])
    with tab1:
        search = st.text_input("Search across order, customer, product, city")
        view = filtered.copy()
        if search:
            mask = view.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False)).any(axis=1)
            view = view[mask]
        st.write(f"Showing {len(view):,} rows")
        st.dataframe(view, use_container_width=True, hide_index=True)
    with tab2:
        st.markdown("**Cleaning rules:** rows with invalid dates, non-positive price/quantity, discounts outside 0–1, or ages outside 0–120 are excluded; exact duplicate rows are removed; missing categorical values become `Unknown`.")
        st.dataframe(quality_report, use_container_width=True, hide_index=True)
        st.markdown("**Missing values in raw input**")
        st.dataframe(raw.isna().sum().rename("Missing Count").reset_index().rename(columns={"index":"Column"}), use_container_width=True, hide_index=True)
    with tab3:
        st.download_button("Download cleaned dataset", cleaned.to_csv(index=False).encode("utf-8"), "cleaned_ecommerce_data.csv", "text/csv")
        st.download_button("Download filtered records", filtered.to_csv(index=False).encode("utf-8"), "filtered_ecommerce_data.csv", "text/csv")
        summary = pd.DataFrame([kpis(filtered)])
        st.download_button("Download KPI summary", summary.to_csv(index=False).encode("utf-8"), "ecommerce_kpi_summary.csv", "text/csv")

elif page == "Business Insights":
    st.subheader("Business Insights & Recommendations")
    for i, insight in enumerate(business_insights(filtered), start=1):
        st.info(f"{i}. {insight}")
    st.markdown("#### How to interpret these insights")
    st.write("These are descriptive findings calculated from the currently filtered data. They can help identify areas for further investigation, but they do not prove why a trend occurred. Validate recommendations with business context before acting on them.")
    st.markdown("#### Revenue definition")
    st.latex(r"\text{Net Revenue} = \text{Quantity} \times \text{Unit Price} \times (1 - \text{Discount})")
    st.write("Revenue KPIs include Completed and Shipped orders. Cancelled and Returned orders are excluded from sales revenue and shown separately in order-status analysis.")

else:
    st.subheader("SQL Explorer")
    st.write("Run a few predefined SQL analytics queries against the SQLite database generated from the cleaned data.")
    options = {
        "Revenue by category": "SELECT p.Category, ROUND(SUM(o.Quantity*o.Unit_Price*(1-o.Discount)),2) AS Revenue FROM orders o JOIN products p ON o.Product_ID=p.Product_ID WHERE o.Order_Status IN ('Completed','Shipped') GROUP BY p.Category ORDER BY Revenue DESC",
        "Top 10 products": "SELECT p.Product_Name, ROUND(SUM(o.Quantity*o.Unit_Price*(1-o.Discount)),2) AS Revenue FROM orders o JOIN products p ON o.Product_ID=p.Product_ID WHERE o.Order_Status IN ('Completed','Shipped') GROUP BY p.Product_Name ORDER BY Revenue DESC LIMIT 10",
        "Monthly revenue": "SELECT substr(Order_Date,1,7) AS Month, ROUND(SUM(Quantity*Unit_Price*(1-Discount)),2) AS Revenue FROM orders WHERE Order_Status IN ('Completed','Shipped') GROUP BY Month ORDER BY Month",
        "Order status": "SELECT Order_Status, COUNT(DISTINCT Order_ID) AS Orders FROM orders GROUP BY Order_Status ORDER BY Orders DESC",
        "City-wise revenue": "SELECT c.City, ROUND(SUM(o.Quantity*o.Unit_Price*(1-o.Discount)),2) AS Revenue FROM orders o JOIN customers c ON o.Customer_ID=c.Customer_ID WHERE o.Order_Status IN ('Completed','Shipped') GROUP BY c.City ORDER BY Revenue DESC"
    }
    choice = st.selectbox("Choose a query", list(options.keys()))
    st.code(options[choice], language="sql")
    try:
        result = query_df(options[choice])
        st.dataframe(result, use_container_width=True, hide_index=True)
    except Exception as e:
        st.error(f"SQL query failed: {e}")

st.divider()
st.caption("MCA Data Analytics Mini-Project • Python · Pandas · SQL/SQLite · Plotly · Streamlit")
