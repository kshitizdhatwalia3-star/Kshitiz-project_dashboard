-- Revenue from completed/shipped orders after discount
SELECT ROUND(SUM(Quantity * Unit_Price * (1 - Discount)), 2) AS net_revenue
FROM orders WHERE Order_Status IN ('Completed', 'Shipped');

-- Order count and units sold
SELECT COUNT(DISTINCT Order_ID) AS total_orders, SUM(Quantity) AS units_sold
FROM orders WHERE Order_Status IN ('Completed', 'Shipped');

-- Revenue by product
SELECT p.Product_Name, ROUND(SUM(o.Quantity * o.Unit_Price * (1 - o.Discount)), 2) AS revenue
FROM orders o JOIN products p ON o.Product_ID = p.Product_ID
WHERE o.Order_Status IN ('Completed', 'Shipped') GROUP BY p.Product_Name ORDER BY revenue DESC LIMIT 10;

-- Monthly revenue
SELECT substr(Order_Date, 1, 7) AS month, ROUND(SUM(Quantity * Unit_Price * (1 - Discount)), 2) AS revenue
FROM orders WHERE Order_Status IN ('Completed', 'Shipped') GROUP BY month ORDER BY month;

-- City-wise revenue
SELECT c.City, ROUND(SUM(o.Quantity * o.Unit_Price * (1 - o.Discount)), 2) AS revenue
FROM orders o JOIN customers c ON o.Customer_ID = c.Customer_ID
WHERE o.Order_Status IN ('Completed', 'Shipped') GROUP BY c.City ORDER BY revenue DESC;

-- Order status distribution
SELECT Order_Status, COUNT(DISTINCT Order_ID) AS orders FROM orders GROUP BY Order_Status ORDER BY orders DESC;
