PRAGMA foreign_keys = ON;
CREATE TABLE customers (Customer_ID TEXT PRIMARY KEY, Customer_Name TEXT, Gender TEXT, Age INTEGER, City TEXT, State TEXT);
CREATE TABLE products (Product_ID TEXT PRIMARY KEY, Product_Name TEXT, Category TEXT);
CREATE TABLE orders (Order_ID TEXT, Order_Date TEXT, Customer_ID TEXT, Product_ID TEXT, Quantity INTEGER, Unit_Price REAL, Discount REAL, Payment_Method TEXT, Order_Status TEXT, PRIMARY KEY (Order_ID, Product_ID), FOREIGN KEY (Customer_ID) REFERENCES customers(Customer_ID), FOREIGN KEY (Product_ID) REFERENCES products(Product_ID));
