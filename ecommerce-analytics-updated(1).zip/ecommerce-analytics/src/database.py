import sqlite3
from pathlib import Path
import pandas as pd

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS customers (
  Customer_ID TEXT PRIMARY KEY, Customer_Name TEXT, Gender TEXT, Age INTEGER, City TEXT, State TEXT
);
CREATE TABLE IF NOT EXISTS products (
  Product_ID TEXT PRIMARY KEY, Product_Name TEXT, Category TEXT
);
CREATE TABLE IF NOT EXISTS orders (
  Order_ID TEXT, Order_Date TEXT, Customer_ID TEXT, Product_ID TEXT,
  Quantity INTEGER, Unit_Price REAL, Discount REAL, Payment_Method TEXT, Order_Status TEXT,
  PRIMARY KEY (Order_ID, Product_ID),
  FOREIGN KEY (Customer_ID) REFERENCES customers(Customer_ID),
  FOREIGN KEY (Product_ID) REFERENCES products(Product_ID)
);
"""

def connect(db_path="ecommerce.db"):
    path = Path(db_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.execute("PRAGMA foreign_keys = ON")
    return con

def initialize_database(df: pd.DataFrame, db_path="ecommerce.db"):
    con = connect(db_path)
    try:
        con.executescript(SCHEMA)
        con.execute("DELETE FROM orders")
        con.execute("DELETE FROM products")
        con.execute("DELETE FROM customers")
        customers = df[["Customer_ID", "Customer_Name", "Gender", "Age", "City", "State"]].drop_duplicates("Customer_ID")
        products = df[["Product_ID", "Product_Name", "Category"]].drop_duplicates("Product_ID")
        orders = df[["Order_ID", "Order_Date", "Customer_ID", "Product_ID", "Quantity", "Unit_Price", "Discount", "Payment_Method", "Order_Status"]]
        customers.to_sql("customers", con, if_exists="append", index=False)
        products.to_sql("products", con, if_exists="append", index=False)
        orders.to_sql("orders", con, if_exists="append", index=False)
        con.commit()
    finally:
        con.close()

def query_df(sql, params=(), db_path="ecommerce.db"):
    con = connect(db_path)
    try:
        return pd.read_sql_query(sql, con, params=params)
    finally:
        con.close()
