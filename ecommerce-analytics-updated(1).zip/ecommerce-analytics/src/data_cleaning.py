import pandas as pd
from .data_loader import COLUMNS

NUMERIC = ["Age", "Quantity", "Unit_Price", "Discount"]
CATEGORICAL = ["Gender", "City", "State", "Product_ID", "Product_Name", "Category", "Payment_Method", "Order_Status", "Customer_ID", "Customer_Name"]


def clean_data(raw: pd.DataFrame):
    """Return (cleaned data, quality report); invalid rows are excluded with counts reported."""
    df = raw.copy()
    missing_columns = [c for c in COLUMNS if c not in df.columns]
    for col in missing_columns:
        df[col] = pd.NA
    df = df[COLUMNS]
    before_rows = len(df)
    duplicate_rows = int(df.duplicated().sum())
    df = df.drop_duplicates().copy()
    df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")
    invalid_dates = int(df["Order_Date"].isna().sum())
    for col in NUMERIC:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    invalid_price = int((df["Unit_Price"] <= 0).sum())
    invalid_quantity = int((df["Quantity"] <= 0).sum())
    invalid_discount = int(((df["Discount"] < 0) | (df["Discount"] > 1)).sum())
    invalid_age = int(((df["Age"] < 0) | (df["Age"] > 120)).sum())
    invalid_mask = df["Order_Date"].isna() | (df["Unit_Price"] <= 0) | (df["Quantity"] <= 0) | (df["Discount"] < 0) | (df["Discount"] > 1) | (df["Age"] < 0) | (df["Age"] > 120)
    excluded_rows = int(invalid_mask.sum())
    df = df.loc[~invalid_mask].copy()
    for col in CATEGORICAL:
        df[col] = df[col].astype("string").str.strip()
        df[col] = df[col].replace("", pd.NA).fillna("Unknown")
    df["Category"] = df["Category"].str.title()
    df["Gender"] = df["Gender"].str.title()
    df["Payment_Method"] = df["Payment_Method"].str.title()
    df["Order_Status"] = df["Order_Status"].str.title()
    df["Order_Date"] = df["Order_Date"].dt.strftime("%Y-%m-%d")
    df["Age"] = df["Age"].fillna(df["Age"].median() if df["Age"].notna().any() else 0).astype(int)
    df["Quantity"] = df["Quantity"].astype(int)
    df["Unit_Price"] = df["Unit_Price"].astype(float).round(2)
    df["Discount"] = df["Discount"].astype(float).round(4)
    report = pd.DataFrame([
        {"Metric": "Input rows", "Value": before_rows},
        {"Metric": "Duplicate rows removed", "Value": duplicate_rows},
        {"Metric": "Invalid dates", "Value": invalid_dates},
        {"Metric": "Invalid prices", "Value": invalid_price},
        {"Metric": "Invalid quantities", "Value": invalid_quantity},
        {"Metric": "Invalid discounts", "Value": invalid_discount},
        {"Metric": "Invalid ages", "Value": invalid_age},
        {"Metric": "Rows excluded by validation", "Value": excluded_rows},
        {"Metric": "Output rows", "Value": len(df)},
        {"Metric": "Missing columns added", "Value": len(missing_columns)},
    ])
    return df.reset_index(drop=True), report
