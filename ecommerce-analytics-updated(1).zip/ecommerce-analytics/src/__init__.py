"""E-commerce analytics package."""
