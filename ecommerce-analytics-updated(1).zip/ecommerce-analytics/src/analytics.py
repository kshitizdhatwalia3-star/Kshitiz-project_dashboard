import pandas as pd

COMPLETED_STATUSES = {"Completed", "Shipped"}

def add_metrics(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if out.empty:
        out["Gross_Sales"] = pd.Series(dtype=float)
        out["Net_Revenue"] = pd.Series(dtype=float)
        return out
    out["Gross_Sales"] = out["Quantity"] * out["Unit_Price"]
    out["Net_Revenue"] = out["Gross_Sales"] * (1 - out["Discount"])
    out["Order_Date"] = pd.to_datetime(out["Order_Date"], errors="coerce")
    return out

def completed_sales(df: pd.DataFrame) -> pd.DataFrame:
    out = add_metrics(df)
    return out[out["Order_Status"].isin(COMPLETED_STATUSES)].copy()

def kpis(df: pd.DataFrame) -> dict:
    sales = completed_sales(df)
    if sales.empty:
        return {"revenue": 0.0, "orders": 0, "units": 0, "aov": 0.0, "customers": 0, "avg_discount": 0.0, "repeat_rate": 0.0, "mom_growth": None}
    order_revenue = sales.groupby("Order_ID")["Net_Revenue"].sum()
    cust_orders = sales.groupby("Customer_ID")["Order_ID"].nunique()
    monthly = sales.assign(Month=sales["Order_Date"].dt.to_period("M")).groupby("Month")["Net_Revenue"].sum().sort_index()
    mom = None
    if len(monthly) >= 2:
        prev = monthly.iloc[-2]
        mom = ((monthly.iloc[-1] - prev) / prev * 100) if prev else None
    return {
        "revenue": float(sales["Net_Revenue"].sum()),
        "orders": int(sales["Order_ID"].nunique()),
        "units": int(sales["Quantity"].sum()),
        "aov": float(order_revenue.mean()) if len(order_revenue) else 0.0,
        "customers": int(sales["Customer_ID"].nunique()),
        "avg_discount": float(sales["Discount"].mean() * 100),
        "repeat_rate": float((cust_orders > 1).mean() * 100) if len(cust_orders) else 0.0,
        "mom_growth": float(mom) if mom is not None else None,
    }

def monthly_revenue(df: pd.DataFrame) -> pd.DataFrame:
    sales = completed_sales(df)
    if sales.empty: return pd.DataFrame(columns=["Month", "Revenue"])
    return sales.assign(Month=sales["Order_Date"].dt.to_period("M").astype(str)).groupby("Month", as_index=False)["Net_Revenue"].sum().rename(columns={"Net_Revenue":"Revenue"}).sort_values("Month")

def group_revenue(df: pd.DataFrame, by: str) -> pd.DataFrame:
    sales = completed_sales(df)
    if sales.empty: return pd.DataFrame(columns=[by, "Revenue", "Units"])
    return sales.groupby(by, as_index=False).agg(Revenue=("Net_Revenue", "sum"), Units=("Quantity", "sum")).sort_values("Revenue", ascending=False)

def order_status_summary(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby("Order_Status", as_index=False).agg(Orders=("Order_ID", "nunique")).sort_values("Orders", ascending=False)

def customer_rfm(df: pd.DataFrame, reference_date=None) -> pd.DataFrame:
    sales = completed_sales(df)
    if sales.empty:
        return pd.DataFrame(columns=["Customer_ID", "Recency", "Frequency", "Monetary", "Segment"])
    ref = pd.Timestamp(reference_date) if reference_date else sales["Order_Date"].max() + pd.Timedelta(days=1)
    rfm = sales.groupby("Customer_ID").agg(Last_Purchase=("Order_Date", "max"), Frequency=("Order_ID", "nunique"), Monetary=("Net_Revenue", "sum")).reset_index()
    rfm["Recency"] = (ref - rfm["Last_Purchase"]).dt.days
    # Transparent rank-based segmentation; useful for demonstration, not a universal business rule.
    r_rank = rfm["Recency"].rank(pct=True, ascending=False)
    f_rank = rfm["Frequency"].rank(pct=True)
    m_rank = rfm["Monetary"].rank(pct=True)
    rfm["Segment"] = "Other Customers"
    rfm.loc[(r_rank >= .75) & (f_rank >= .75) & (m_rank >= .75), "Segment"] = "Champions"
    rfm.loc[(rfm["Segment"] == "Other Customers") & (f_rank >= .65) & (m_rank >= .60), "Segment"] = "Loyal Customers"
    rfm.loc[(rfm["Segment"] == "Other Customers") & (r_rank >= .60) & (f_rank >= .50), "Segment"] = "Potential Loyalists"
    rfm.loc[(rfm["Segment"] == "Other Customers") & (rfm["Recency"] >= rfm["Recency"].quantile(.75)), "Segment"] = "At-Risk Customers"
    return rfm.drop(columns="Last_Purchase").sort_values("Monetary", ascending=False)

def business_insights(df: pd.DataFrame) -> list[str]:
    sales = completed_sales(df)
    if sales.empty: return ["No completed or shipped orders are available for the selected filters."]
    insights = []
    cat = group_revenue(sales, "Category")
    if not cat.empty:
        insights.append(f"{cat.iloc[0]['Category']} is the highest-revenue category in the selected data, generating ₹{cat.iloc[0]['Revenue']:,.0f}.")
    products = group_revenue(sales, "Product_Name")
    if not products.empty:
        insights.append(f"{products.iloc[0]['Product_Name']} is the leading product by revenue, with ₹{products.iloc[0]['Revenue']:,.0f}.")
    k = kpis(sales)
    insights.append(f"Average order value is ₹{k['aov']:,.2f} across {k['orders']:,} completed/shipped orders.")
    if k["mom_growth"] is not None:
        direction = "increased" if k["mom_growth"] >= 0 else "decreased"
        insights.append(f"Revenue {direction} by {abs(k['mom_growth']):.1f}% compared with the previous available month. This is descriptive and does not explain the cause.")
    insights.append(f"Repeat-customer rate is {k['repeat_rate']:.1f}%; consider loyalty offers and relevant follow-up campaigns if repeat purchasing is a business priority.")
    return insights
