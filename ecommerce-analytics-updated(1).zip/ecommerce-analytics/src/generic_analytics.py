"""Safe descriptive analytics for arbitrary CSV datasets."""
import pandas as pd


def profile_data(df):
    if df.empty or len(df.columns) == 0:
        raise ValueError('CSV must have at least one row and one column.')
    if df.columns.duplicated().any():
        raise ValueError('Duplicate column names are not supported.')
    info = pd.DataFrame({'Column': df.columns, 'Data type': [str(t) for t in df.dtypes], 'Missing': df.isna().sum().values, 'Unique': df.nunique(dropna=True).values})
    return info, int(df.duplicated().sum())


def clean_generic(df):
    result = df.drop_duplicates().copy()
    for col in result.select_dtypes(include='object').columns:
        result[col] = result[col].map(lambda x: x.strip() if isinstance(x, str) else x)
        result[col] = result[col].replace('', pd.NA)
    return result.reset_index(drop=True)


def filter_generic(df, selections):
    result = df
    for col, values in selections.items():
        result = result[result[col].astype('string').isin(values)]
    return result
