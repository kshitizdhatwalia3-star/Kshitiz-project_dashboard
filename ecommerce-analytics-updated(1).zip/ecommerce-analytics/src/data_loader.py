from pathlib import Path
import numpy as np
import pandas as pd

COLUMNS = ["Order_ID", "Order_Date", "Customer_ID", "Customer_Name", "Gender", "Age", "City", "State", "Product_ID", "Product_Name", "Category", "Quantity", "Unit_Price", "Discount", "Payment_Method", "Order_Status"]

PRODUCTS = [
    ("P001", "Wireless Headphones", "Electronics", 2499),
    ("P002", "Smart Watch", "Electronics", 3999),
    ("P003", "USB-C Charger", "Electronics", 799),
    ("P004", "Running Shoes", "Fashion", 2299),
    ("P005", "Cotton T-Shirt", "Fashion", 699),
    ("P006", "Backpack", "Fashion", 1299),
    ("P007", "Coffee Maker", "Home & Kitchen", 3199),
    ("P008", "Water Bottle", "Home & Kitchen", 499),
    ("P009", "Desk Lamp", "Home & Kitchen", 999),
    ("P010", "Novel Collection", "Books", 899),
    ("P011", "Notebook Set", "Books", 299),
    ("P012", "Yoga Mat", "Sports", 1099),
    ("P013", "Cricket Bat", "Sports", 1899),
    ("P014", "Skin Care Kit", "Beauty", 1499),
    ("P015", "Hair Dryer", "Beauty", 1799),
]
CITIES = [("Chandigarh", "Chandigarh"), ("Ludhiana", "Punjab"), ("Amritsar", "Punjab"), ("Shimla", "Himachal Pradesh"), ("Bilaspur", "Himachal Pradesh"), ("Delhi", "Delhi"), ("Jaipur", "Rajasthan"), ("Mumbai", "Maharashtra"), ("Pune", "Maharashtra"), ("Bengaluru", "Karnataka"), ("Hyderabad", "Telangana"), ("Lucknow", "Uttar Pradesh")]


def generate_sample_data(n: int = 5000, seed: int = 42) -> pd.DataFrame:
    """Generate clearly simulated e-commerce line-item data."""
    rng = np.random.default_rng(seed)
    start = pd.Timestamp("2024-01-01")
    end = pd.Timestamp("2026-09-30")
    days = (end - start).days
    customers = [f"C{i:05d}" for i in range(1, 1001)]
    names = [f"Customer {i:04d}" for i in range(1, 1001)]
    product_idx = rng.integers(0, len(PRODUCTS), size=n)
    city_idx = rng.integers(0, len(CITIES), size=n)
    customer_idx = rng.integers(0, len(customers), size=n)
    dates = start + pd.to_timedelta(rng.integers(0, days + 1, size=n), unit="D")
    quantity = rng.choice([1, 1, 1, 2, 2, 3, 4], size=n)
    discounts = rng.choice([0, 0.05, 0.10, 0.15, 0.20], size=n, p=[.38, .16, .24, .14, .08])
    statuses = rng.choice(["Completed", "Completed", "Completed", "Shipped", "Processing", "Cancelled", "Returned"], size=n, p=[.42, .18, .12, .12, .07, .06, .03])
    rows = []
    for i in range(n):
        p = PRODUCTS[product_idx[i]]
        city, state = CITIES[city_idx[i]]
        c = customer_idx[i]
        rows.append({
            "Order_ID": f"O{i+1:06d}", "Order_Date": dates[i].strftime("%Y-%m-%d"),
            "Customer_ID": customers[c], "Customer_Name": names[c],
            "Gender": rng.choice(["Female", "Male", "Other"]), "Age": int(rng.integers(18, 66)),
            "City": city, "State": state, "Product_ID": p[0], "Product_Name": p[1],
            "Category": p[2], "Quantity": int(quantity[i]),
            "Unit_Price": round(float(p[3] * rng.uniform(.85, 1.15)), 2),
            "Discount": float(discounts[i]), "Payment_Method": rng.choice(["UPI", "Credit Card", "Debit Card", "Cash on Delivery", "Net Banking"]),
            "Order_Status": statuses[i]
        })
    df = pd.DataFrame(rows, columns=COLUMNS)
    # Add a small, intentional amount of data-quality noise for demonstrating cleaning.
    if n >= 100:
        df.loc[3, "City"] = None
        df.loc[10, "Category"] = " electronics "
        df.loc[20, "Discount"] = 1.25
        df.loc[30, "Unit_Price"] = -100
    return df


def load_csv(uploaded_file=None, default_path="data/sample_ecommerce.csv") -> pd.DataFrame:
    if uploaded_file is not None:
        return pd.read_csv(uploaded_file)
    path = Path(default_path)
    if not path.exists():
        path = Path(__file__).resolve().parents[1] / default_path
    if not path.exists():
        return generate_sample_data()
    return pd.read_csv(path)
