# E-Commerce Sales & Customer Behavior Analytics Dashboard

A runnable MCA Data Analytics mini-project built with Python, Pandas, NumPy, SQLite/SQL, Plotly, and Streamlit. It demonstrates data cleaning, KPI calculation, sales analysis, customer analysis, RFM segmentation, downloadable reports, and evidence-based descriptive insights.

> **Dataset note:** The included sample data is synthetic and is intended for learning and demonstration only. It is not actual company transaction data.

## Features

- Executive overview with revenue, orders, units, average order value, customers, average discount, repeat customer rate, and month-over-month growth.
- Sales, customer, and product analytics pages.
- CSV upload, data validation, data-quality report, and cleaned/filtered CSV downloads.
- SQLite database with customers, products, and orders tables.
- SQL Explorer with predefined analytical queries.
- Optional rank-based RFM segmentation.
- Interactive Plotly charts and global sidebar filters.
- Automated tests for core analytics.

## Project structure

```text
ecommerce-analytics/
├── app.py
├── requirements.txt
├── README.md
├── ecommerce.db                 # created/refreshed when app runs
├── data/
│   └── sample_ecommerce.csv
├── src/
│   ├── __init__.py
│   ├── data_loader.py
│   ├── data_cleaning.py
│   ├── database.py
│   └── analytics.py
├── sql/
│   ├── schema.sql
│   └── analysis_queries.sql
├── reports/
└── tests/
    └── test_analytics.py
```

## Requirements

- Python 3.10 or newer (recommended: Python 3.11 or 3.12)
- Internet access for the initial dependency installation
- VS Code or another Python editor (optional)

## Windows PowerShell installation

Open PowerShell in the project folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks virtual-environment activation, you can run the venv's Python directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

The browser should open automatically. If not, open the local URL printed in the terminal.

## Run tests

```powershell
python -m pytest -q
```

## CSV upload format

The uploaded CSV should have these columns (column names are case-sensitive in this initial version):

`Order_ID, Order_Date, Customer_ID, Customer_Name, Gender, Age, City, State, Product_ID, Product_Name, Category, Quantity, Unit_Price, Discount, Payment_Method, Order_Status`

`Order_Date` should be parseable as a date. `Quantity` and `Unit_Price` must be positive. `Discount` must be a decimal from 0 to 1 (for example, `0.10` means 10%).

## KPI definitions

- **Gross sales:** `Quantity × Unit Price`.
- **Net revenue:** `Quantity × Unit Price × (1 − Discount)`.
- **Revenue orders included:** Completed and Shipped.
- **Total orders:** Distinct order IDs in included statuses.
- **Average order value:** Total net revenue divided by distinct included order IDs, after aggregating line items within each order.
- **Repeat customer rate:** Share of included customers with more than one distinct included order.
- **Month-over-month growth:** Percentage change in revenue between the two latest months available in the selected data.

Cancelled orders and returned orders are excluded from sales revenue; they remain visible in order-status analysis. Returned/refund accounting would need a separate refund amount field in a real dataset.

## Data cleaning rules

- Exact duplicate rows are removed.
- Invalid/unparseable dates are excluded.
- Rows with non-positive unit prices or quantities are excluded.
- Rows with discounts outside 0–1 are excluded.
- Ages outside 0–120 are excluded.
- Missing categorical values are labeled `Unknown`.
- Category and several categorical labels are trimmed and normalized.
- The Data Explorer shows the raw-input missing-value counts and cleaning report.

The cleaning module adds missing required columns as blank before validation, so a CSV missing critical fields may result in many rows being excluded. Use the documented column format for best results.

## SQL concepts demonstrated

- `SELECT`, `WHERE`, `GROUP BY`, `ORDER BY`, and `LIMIT`
- Aggregate functions such as `SUM` and `COUNT(DISTINCT ...)`
- Joins between orders, customers, and products
- Date string grouping for monthly trends
- Primary keys and foreign-key relationships

The SQL files in `sql/` provide reusable schema and query examples. The in-app SQL Explorer runs predefined queries against the refreshed SQLite database.

## RFM segmentation

- **Recency:** Days since the latest completed/shipped purchase.
- **Frequency:** Number of distinct completed/shipped orders.
- **Monetary:** Total net revenue from completed/shipped orders.

The project uses simple rank-based demonstration rules to label Champions, Loyal Customers, Potential Loyalists, At-Risk Customers, and Other Customers. The segments are illustrative, not a validated business policy. Tune the rules against the real business context before operational use.

## Limitations

- The included data is simulated; results do not describe a real company.
- Month-over-month growth uses the latest two months present in the filtered data, which may be partial months.
- RFM segmentation is a transparent demonstration heuristic, not a trained predictive model.
- Regional comparisons use city/state labels rather than geospatial coordinates.
- Excel export is not included in the first version; CSV exports are provided.

## Future enhancements

- Add normalized aliases for uploaded CSV columns.
- Add true order-level IDs with multiple line items in generated data.
- Add Excel/PDF report generation.
- Add authenticated user access and database persistence for multi-user deployment.
- Add unit economics, refunds, profit margins, cohort retention, and forecasting when reliable fields are available.

## Project abstract

This project develops an interactive e-commerce sales and customer behavior analytics dashboard using Python, Pandas, SQL/SQLite, Plotly, and Streamlit. It processes transactional data through validation and cleaning, calculates business KPIs, and visualizes sales trends, product/category performance, geographic patterns, and customer purchasing behavior. A rank-based RFM module demonstrates customer segmentation, while the SQL Explorer illustrates relational data querying. The application supports CSV upload and downloadable analytical outputs, providing a practical demonstration of the end-to-end data analytics workflow. The bundled synthetic dataset enables reproducible testing and classroom demonstrations without exposing real customer information.
