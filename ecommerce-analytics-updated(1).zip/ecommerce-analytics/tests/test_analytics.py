import pandas as pd
from src.analytics import add_metrics, kpis, monthly_revenue, customer_rfm
from src.data_cleaning import clean_data


def sample():
    return pd.DataFrame([
        {"Order_ID":"O1","Order_Date":"2025-01-01","Customer_ID":"C1","Customer_Name":"A","Gender":"Female","Age":25,"City":"Delhi","State":"Delhi","Product_ID":"P1","Product_Name":"Thing","Category":"Home","Quantity":2,"Unit_Price":100.0,"Discount":0.1,"Payment_Method":"UPI","Order_Status":"Completed"},
        {"Order_ID":"O1","Order_Date":"2025-01-01","Customer_ID":"C1","Customer_Name":"A","Gender":"Female","Age":25,"City":"Delhi","State":"Delhi","Product_ID":"P2","Product_Name":"Other","Category":"Home","Quantity":1,"Unit_Price":50.0,"Discount":0.0,"Payment_Method":"UPI","Order_Status":"Completed"},
        {"Order_ID":"O2","Order_Date":"2025-02-01","Customer_ID":"C1","Customer_Name":"A","Gender":"Female","Age":25,"City":"Delhi","State":"Delhi","Product_ID":"P1","Product_Name":"Thing","Category":"Home","Quantity":1,"Unit_Price":100.0,"Discount":0.0,"Payment_Method":"UPI","Order_Status":"Shipped"},
        {"Order_ID":"O3","Order_Date":"2025-02-03","Customer_ID":"C2","Customer_Name":"B","Gender":"Male","Age":30,"City":"Pune","State":"Maharashtra","Product_ID":"P3","Product_Name":"New","Category":"Books","Quantity":1,"Unit_Price":100.0,"Discount":0.0,"Payment_Method":"Card","Order_Status":"Cancelled"},
    ])

def test_revenue_and_aov():
    k = kpis(sample())
    assert k["revenue"] == 330.0
    assert k["orders"] == 2
    assert k["units"] == 4
    assert k["aov"] == 165.0

def test_cleaning_excludes_invalid_discount():
    df = sample()
    df.loc[0, "Discount"] = 2.0
    cleaned, report = clean_data(df)
    assert len(cleaned) == 3
    assert "Rows excluded by validation" in report["Metric"].values

def test_monthly_revenue():
    m = monthly_revenue(sample())
    assert len(m) == 2
    assert list(m["Month"]) == ["2025-01", "2025-02"]

def test_rfm_segments():
    rfm = customer_rfm(sample())
    assert set(["Recency", "Frequency", "Monetary", "Segment"]).issubset(rfm.columns)
