import pandas as pd
import pytest
from src.generic_analytics import profile_data, clean_generic, filter_generic

def test_profile():
    df = pd.DataFrame({'Marks': [50, 50], 'Class': ['A', 'A']})
    profile, duplicates = profile_data(df)
    assert duplicates == 1 and len(profile) == 2

def test_clean():
    df = pd.DataFrame({'City': [' Delhi ', ' Delhi ', '']})
    cleaned = clean_generic(df)
    assert len(cleaned) == 2
    assert cleaned.loc[0, 'City'] == 'Delhi'

def test_filter():
    df = pd.DataFrame({'Class': ['A', 'B'], 'Marks': [80, 70]})
    assert len(filter_generic(df, {'Class': ['A']})) == 1

def test_empty():
    with pytest.raises(ValueError):
        profile_data(pd.DataFrame())
