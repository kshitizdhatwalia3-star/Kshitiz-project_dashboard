# Student Performance Prediction System 🎓

A machine learning project that predicts student performance using Linear Regression and Decision Tree models with an interactive GUI.

## 📋 Project Overview

This system analyzes student performance based on multiple factors and provides predictions using two different ML algorithms:
- **Linear Regression**: Provides interpretable linear predictions
- **Decision Tree Regressor**: Captures non-linear patterns in student data

### Key Features
✅ Interactive GUI built with Tkinter  
✅ Two ML models (Linear Regression & Decision Tree)  
✅ Real dataset included (StudentPerformanceFactors.csv)  
✅ Visual plots and metrics display  
✅ Model performance comparison (R² Score, MSE)  
✅ Real-time prediction capability  

---

## 📦 Contents

```
student-performance-prediction/
├── student_performance_prediction_ml.py    # Main application file
├── StudentPerformanceFactors.csv           # Dataset (900+ records)
├── README.md                                # This file
└── requirements.txt                         # Python dependencies
```

---

## 🚀 Installation & Setup

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Extract the zip file
```bash
unzip student_performance_prediction.zip
cd student_performance_prediction
```

### Step 2: Install dependencies
```bash
pip install -r requirements.txt
```

Or install manually:
```bash
pip install pandas numpy scikit-learn matplotlib
```

---

## 💻 How to Use

### Running the Application
```bash
python student_performance_prediction_ml.py
```

The GUI will launch with the following components:

#### **Main Interface Sections:**

1. **Data Loading Panel**
   - Load the pre-included CSV dataset
   - Or upload your own CSV file
   - View dataset statistics

2. **Feature Selection**
   - Study Hours (0-12 hours)
   - Attendance (0-100%)
   - Previous Marks (0-100)
   - Sleep Hours (0-10 hours)
   - Assignments Done (0-50)
   - Mock Score (0-100)

3. **Model Training**
   - Split data into training/testing sets
   - Train both Linear Regression and Decision Tree models
   - View performance metrics:
     - R² Score (higher is better, max 1.0)
     - Mean Squared Error (lower is better)

4. **Predictions**
   - Adjust sliders for student factors
   - Get real-time predictions from both models
   - Compare model outputs

5. **Visualizations**
   - Actual vs Predicted performance scatter plots
   - Residual analysis
   - Feature importance (for Decision Tree)
   - Model performance comparison

---

## 📊 Dataset Information

**File:** `StudentPerformanceFactors.csv`

### Features (Input Variables):
| Feature | Range | Description |
|---------|-------|-------------|
| study_hours | 0-12 | Daily study hours |
| attendance | 0-100 | Class attendance percentage |
| previous_marks | 0-100 | Marks from previous term |
| sleep_hours | 0-10 | Average daily sleep |
| assignments | 0-50 | Number of assignments completed |
| mock_score | 0-100 | Score on mock exam |

### Target Variable:
| Variable | Range | Description |
|----------|-------|-------------|
| final_marks | 0-100 | Final exam marks (what we predict) |

### Dataset Stats:
- **Records:** 900+ samples
- **Features:** 6 input variables
- **Target:** final_marks
- **Format:** CSV (comma-separated values)

---

## 🤖 Models Explained

### Linear Regression
- **What it does:** Finds a straight-line relationship between features and performance
- **Pros:** Simple, interpretable, fast
- **Cons:** May miss complex patterns
- **Best for:** When relationship is roughly linear

### Decision Tree Regressor
- **What it does:** Creates a tree of decisions to predict performance
- **Pros:** Captures non-linear patterns, shows feature importance
- **Cons:** Can overfit on small data
- **Best for:** Complex, non-linear relationships

---

## 📈 Understanding Results

### R² Score
- Range: 0 to 1 (perfect = 1.0)
- Represents how well the model fits the data
- Example: R² = 0.85 means model explains 85% of variance

### Mean Squared Error (MSE)
- Average of squared prediction errors
- Lower is better
- Helps identify which model generalizes better

### Visualization Guide
- **Actual vs Predicted:** Points near the diagonal line = good predictions
- **Residuals:** Should be randomly scattered around zero
- **Feature Importance:** Longer bars = more important features

---

## 🔧 Customization

### Using Your Own Dataset

Your CSV file must include:
- Column names matching: `study_hours`, `attendance`, `previous_marks`, `sleep_hours`, `assignments`, `mock_score`, `final_marks`
- OR modify `FEATURE_COLS` in the code to match your column names

Example CSV format:
```csv
study_hours,attendance,previous_marks,sleep_hours,assignments,mock_score,final_marks
8,85,78,7,42,82,88
6,90,85,8,48,90,92
```

### Adjusting Feature Ranges

Edit these lines in the code (around line 48-70):
```python
FEATURE_RANGES = {
    "study_hours": (0, 12, 1, 6, "hours"),
    "attendance": (0, 100, 5, 85, "%"),
    # ... modify ranges as needed
}
```

---

## 🐛 Troubleshooting

### Error: "No module named 'pandas'"
**Solution:** Install dependencies
```bash
pip install -r requirements.txt
```

### Error: "File not found"
**Solution:** Make sure `StudentPerformanceFactors.csv` is in the same directory as the Python file

### GUI doesn't appear
**Solution:** Ensure you have a display environment (not running on headless server)
```bash
pip install --upgrade tkinter
```

### Predictions seem off
**Solution:** 
- Try retraining the models
- Check if your input values are within typical ranges
- Consider training on more diverse data

---

## 📚 Learning Resources

### Key ML Concepts
- [Scikit-learn Documentation](https://scikit-learn.org/)
- [Linear Regression Guide](https://en.wikipedia.org/wiki/Linear_regression)
- [Decision Tree Learning](https://en.wikipedia.org/wiki/Decision_tree_learning)
- [Train-Test Split](https://towardsdatascience.com/train-test-split-explained-7f32d0f3ae0c)

### Python & Data Science
- [Pandas Tutorial](https://pandas.pydata.org/docs/)
- [NumPy Guide](https://numpy.org/doc/stable/)
- [Matplotlib Plotting](https://matplotlib.org/stable/tutorials/index.html)

---

## 🎯 Next Steps & Improvements

### Potential Enhancements:
- [ ] Add more models (Random Forest, Gradient Boosting, Neural Networks)
- [ ] Cross-validation for better evaluation
- [ ] Feature scaling/normalization
- [ ] Hyperparameter tuning
- [ ] Save/load trained models
- [ ] Export predictions to CSV
- [ ] Add data preprocessing pipeline
- [ ] Implement k-fold cross-validation

### Advanced Features:
- Ensemble methods combining multiple models
- Feature interaction analysis
- Prediction confidence intervals
- Student performance clustering
- Benchmark against real exam data

---

## 📝 Code Structure

### Main Components:
1. **Data Loading**: `load_data()` - Loads CSV files
2. **Preprocessing**: Data cleaning and splitting
3. **Model Training**: `train_models()` - Trains both algorithms
4. **Prediction**: `predict_performance()` - Makes predictions
5. **Visualization**: `plot_results()` - Creates charts and graphs
6. **GUI**: Tkinter interface with tabs and controls

### Key Functions:
```python
load_data(filepath)              # Load CSV dataset
train_models(X, y)               # Train both models
predict_performance(features)    # Predict for new inputs
evaluate_model(y_true, y_pred)  # Calculate metrics
plot_actual_vs_predicted()       # Create scatter plot
```

---

## ⚖️ License & Attribution

This project is provided as-is for educational purposes.

### Libraries Used:
- pandas (Data manipulation)
- numpy (Numerical computing)
- scikit-learn (Machine learning)
- matplotlib (Visualization)
- tkinter (GUI framework)

---

## 💡 Tips for Best Results

1. **Train with diverse data** - Include students with varying study habits
2. **Monitor overfitting** - Compare train vs test metrics
3. **Validate predictions** - Check if results match real student outcomes
4. **Feature importance** - Focus on what actually affects performance
5. **Regular retraining** - Update models with new student data
6. **Check assumptions** - Linear Regression assumes linear relationships

---

## 📞 Support & Questions

For issues or questions:
1. Check the Troubleshooting section above
2. Review error messages carefully
3. Verify all dependencies are installed
4. Check dataset format matches requirements
5. Try with the included sample dataset first

---

## 🎓 Educational Value

This project demonstrates:
- ✅ ML model implementation
- ✅ Train-test data splitting
- ✅ Model evaluation and comparison
- ✅ GUI development with Python
- ✅ Data visualization
- ✅ Real-world prediction system
- ✅ Code organization and documentation

Perfect for learning ML fundamentals!

---

**Last Updated:** 2024  
**Status:** Ready for use and learning  
**Difficulty Level:** Beginner to Intermediate
