"""
╔══════════════════════════════════════════════════════════════════╗
║         STUDENT PERFORMANCE PREDICTION SYSTEM                   ║
║         ML Project using Linear Regression & Decision Tree      ║
║         Supports Kaggle CSV Upload + Synthetic Dataset          ║
╚══════════════════════════════════════════════════════════════════╝

Libraries: pandas, numpy, scikit-learn, matplotlib, tkinter
"""

# ─── Standard Library ────────────────────────────────────────────
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import os
import warnings
warnings.filterwarnings("ignore")

# ─── Data & ML ───────────────────────────────────────────────────
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import StandardScaler

# ─── Visualisation ───────────────────────────────────────────────
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure


# ══════════════════════════════════════════════════════════════════
#  CONSTANTS — Features & UI Colours
# ══════════════════════════════════════════════════════════════════

FEATURE_COLS = [
    "study_hours", "attendance", "previous_marks",
    "sleep_hours", "assignments", "mock_score"
]
FEATURE_LABELS = [
    "Study Hours", "Attendance (%)", "Previous Marks",
    "Sleep Hours", "Assignments Done", "Mock Score"
]
FEATURE_RANGES = {
    # key: (min, max, resolution, default, unit)
    # Ranges match StudentPerformanceFactors.csv real data
    "study_hours"    : (1,  44,  1,   20, " hrs/wk"),
    "attendance"     : (60, 100, 1,   80, " %"),
    "previous_marks" : (40, 100, 1,   70, ""),
    "sleep_hours"    : (4,  10,  0.5, 7,  " hrs"),
    "assignments"    : (0,  10,  1,   5,  ""),
    "mock_score"     : (0,  8,   1,   2,  " sessions"),
}

# ── Colour Palette ──────────────────────────────────────────────
BG_DARK   = "#0d1117"
BG_CARD   = "#161b22"
BG_LIGHT  = "#21262d"
ACCENT    = "#58a6ff"
ACCENT2   = "#f78166"
TEXT_PRI  = "#e6edf3"
TEXT_SEC  = "#8b949e"
BORDER    = "#30363d"
SUCCESS   = "#3fb950"
WARNING   = "#d29922"
DANGER    = "#f85149"
UPLOAD_BG = "#1c2a1c"
UPLOAD_FG = "#3fb950"

# ── Default Kaggle Dataset Path ─────────────────────────────────
DEFAULT_CSV_PATH = r"C:\Users\kshit\Downloads\StudentPerformanceFactors.csv"

# ── Direct Column Mapping for StudentPerformanceFactors.csv ──────
# Exact CSV column → internal name (zero guessing, always works)
DIRECT_MAPPING = {
    "Hours_Studied"             : "study_hours",
    "Attendance"                : "attendance",
    "Previous_Scores"           : "previous_marks",
    "Sleep_Hours"               : "sleep_hours",
    "Extracurricular_Activities": "assignments",   # Yes/No encoded as 1/0
    "Tutoring_Sessions"         : "mock_score",
    "Exam_Score"                : "final_marks",
}

FONT_H1   = ("Segoe UI", 18, "bold")
FONT_H2   = ("Segoe UI", 13, "bold")
FONT_H3   = ("Segoe UI", 11, "bold")
FONT_BODY = ("Segoe UI", 10)
FONT_MONO = ("Consolas", 11)
FONT_BIG  = ("Segoe UI", 36, "bold")
FONT_SM   = ("Segoe UI",  9)


# ══════════════════════════════════════════════════════════════════
#  1.  SYNTHETIC DATASET GENERATOR (fallback)
# ══════════════════════════════════════════════════════════════════

def generate_dataset(n_samples=800, seed=42):
    """Generates a realistic synthetic student academic dataset."""
    rng = np.random.default_rng(seed)

    study_hours    = rng.uniform(0.5, 10,  n_samples)
    attendance     = rng.uniform(40,  100, n_samples)
    previous_marks = rng.uniform(30,  100, n_samples)
    sleep_hours    = rng.uniform(4,   10,  n_samples)
    assignments    = rng.integers(0,  11,  n_samples).astype(float)
    mock_score     = rng.uniform(20,  100, n_samples)

    final_marks = (
        study_hours    * 3.5  +
        attendance     * 0.25 +
        previous_marks * 0.30 +
        sleep_hours    * 1.2  +
        assignments    * 1.8  +
        mock_score     * 0.20 +
        rng.normal(0, 4, n_samples)
    )
    final_marks = np.clip(final_marks, 0, 100)

    return pd.DataFrame({
        "study_hours"    : np.round(study_hours,    2),
        "attendance"     : np.round(attendance,     1),
        "previous_marks" : np.round(previous_marks, 1),
        "sleep_hours"    : np.round(sleep_hours,    2),
        "assignments"    : assignments,
        "mock_score"     : np.round(mock_score,     1),
        "final_marks"    : np.round(final_marks,    1),
    })


# ══════════════════════════════════════════════════════════════════
#  2.  KAGGLE CSV LOADER + SMART COLUMN MAPPER
# ══════════════════════════════════════════════════════════════════

# Synonym dictionary: normalised CSV column name -> our internal name
# Covers virtually every popular Kaggle student-performance dataset
KAGGLE_SYNONYM_MAP = {

    # ── study_hours ──────────────────────────────────────────────
    "study_hours"            : "study_hours",
    "studyhours"             : "study_hours",
    "hours_studied"          : "study_hours",
    "hours studied"          : "study_hours",
    "hoursstudied"           : "study_hours",
    "study_time"             : "study_hours",
    "studytime"              : "study_hours",
    "daily_study_hours"      : "study_hours",
    "studying_hours"         : "study_hours",
    "time_studying"          : "study_hours",
    "time_spent_studying"    : "study_hours",
    "weekly_study_hours"     : "study_hours",
    "study_hours_per_day"    : "study_hours",
    "hrs_studied"            : "study_hours",

    # ── attendance ───────────────────────────────────────────────
    "attendance"             : "attendance",
    "attendance_percentage"  : "attendance",
    "attendance_%"           : "attendance",
    "attendance_rate"        : "attendance",
    "class_attendance"       : "attendance",
    "school_attendance"      : "attendance",
    "college_attendance"     : "attendance",
    "attendance_(%)"         : "attendance",
    "attend"                 : "attendance",
    "attendancerate"         : "attendance",
    "attendance_pct"         : "attendance",
    "presence"               : "attendance",
    "present_days"           : "attendance",

    # ── previous_marks ───────────────────────────────────────────
    "previous_marks"         : "previous_marks",
    "previousmarks"          : "previous_marks",
    "previous_scores"        : "previous_marks",
    "previous_score"         : "previous_marks",
    "past_marks"             : "previous_marks",
    "past_scores"            : "previous_marks",
    "previous_grade"         : "previous_marks",
    "prior_marks"            : "previous_marks",
    "prior_scores"           : "previous_marks",
    "scores"                 : "previous_marks",
    "previous_exam_score"    : "previous_marks",
    "last_exam_score"        : "previous_marks",
    "midterm_score"          : "previous_marks",
    "midterm_marks"          : "previous_marks",
    "internal_marks"         : "previous_marks",
    "test1"                  : "previous_marks",
    "test_1"                 : "previous_marks",
    "quiz_scores"            : "previous_marks",
    "previous_results"       : "previous_marks",

    # ── sleep_hours ──────────────────────────────────────────────
    "sleep_hours"            : "sleep_hours",
    "sleephours"             : "sleep_hours",
    "sleep"                  : "sleep_hours",
    "hours_sleep"            : "sleep_hours",
    "sleeping_hours"         : "sleep_hours",
    "sleep_duration"         : "sleep_hours",
    "avg_sleep_hours"        : "sleep_hours",
    "hours_of_sleep"         : "sleep_hours",
    "daily_sleep_hours"      : "sleep_hours",
    "sleep_per_night"        : "sleep_hours",
    "rest_hours"             : "sleep_hours",

    # ── assignments ──────────────────────────────────────────────
    "assignments"                    : "assignments",
    "assignments_completed"          : "assignments",
    "completed_assignments"          : "assignments",
    "homework"                       : "assignments",
    "homework_completed"             : "assignments",
    "extracurricular_activities"     : "assignments",
    "extra_curricular_activities"    : "assignments",
    "assignments_done"               : "assignments",
    "no_of_assignments"              : "assignments",
    "num_assignments"                : "assignments",
    "projects_completed"             : "assignments",
    "tasks_completed"                : "assignments",
    "activities"                     : "assignments",
    "participation"                  : "assignments",
    "coursework_completed"           : "assignments",
    "sample_question_papers_practiced": "assignments",

    # ── mock_score ───────────────────────────────────────────────
    "mock_score"             : "mock_score",
    "mockscore"              : "mock_score",
    "mock_test"              : "mock_score",
    "mock_exam"              : "mock_score",
    "mock_test_score"        : "mock_score",
    "practice_score"         : "mock_score",
    "practice_test_score"    : "mock_score",
    "tutoring_sessions"      : "mock_score",
    "tutor_sessions"         : "mock_score",
    "test_scores"            : "mock_score",
    "prep_score"             : "mock_score",
    "diagnostic_score"       : "mock_score",
    "formative_score"        : "mock_score",
    "mock_marks"             : "mock_score",
    "practice_marks"         : "mock_score",
    "internal_test"          : "mock_score",

    # ── final_marks (target) ─────────────────────────────────────
    "final_marks"            : "final_marks",
    "finalmarks"             : "final_marks",
    "final_score"            : "final_marks",
    "final_scores"           : "final_marks",
    "performance_index"      : "final_marks",
    "performance index"      : "final_marks",
    "performanceindex"       : "final_marks",
    "exam_score"             : "final_marks",
    "exam_scores"            : "final_marks",
    "examscore"              : "final_marks",
    "total_score"            : "final_marks",
    "grade"                  : "final_marks",
    "grades"                 : "final_marks",
    "marks"                  : "final_marks",
    "result"                 : "final_marks",
    "score"                  : "final_marks",
    "final_exam_score"       : "final_marks",
    "final_exam_marks"       : "final_marks",
    "overall_score"          : "final_marks",
    "total_marks"            : "final_marks",
    "achievement_score"      : "final_marks",
    "academic_performance"   : "final_marks",
    "gpa"                    : "final_marks",
    "cgpa"                   : "final_marks",
    "percentage"             : "final_marks",
    "pass_fail"              : "final_marks",
    "output"                 : "final_marks",
    "target"                 : "final_marks",
    "label"                  : "final_marks",
}

ALL_REQUIRED = FEATURE_COLS + ["final_marks"]


def auto_map_columns(raw_cols):
    """
    Attempts to auto-map raw CSV columns to required internal names.
    Normalises: strips whitespace, lowercases, collapses spaces/hyphens to underscores.
    Returns { raw_col_name: internal_name } for matched columns.
    """
    import re
    mapping = {}
    for col in raw_cols:
        # Aggressive normalisation: lower, strip, replace spaces/hyphens/dots with _
        key = re.sub(r"[\s\-\.]+", "_", col.strip().lower())
        key = re.sub(r"[^a-z0-9_%()]+", "", key)   # keep only safe chars
        key = re.sub(r"_+", "_", key).strip("_")    # collapse multiple underscores

        if key in KAGGLE_SYNONYM_MAP:
            mapping[col] = KAGGLE_SYNONYM_MAP[key]
        # Also try with original spaces replaced (handles "Hours Studied" etc.)
        elif col.strip().lower() in KAGGLE_SYNONYM_MAP:
            mapping[col] = KAGGLE_SYNONYM_MAP[col.strip().lower()]
    return mapping


def load_and_prepare_csv(filepath, user_mapping):
    """
    Loads a CSV, applies user_mapping, normalises columns,
    handles Yes/No text columns, scales target to 0-100 if needed.
    Returns (prepared_dataframe, info_message_string).
    """
    raw = pd.read_csv(filepath)

    # ── Encode Yes/No text columns BEFORE renaming ───────────────
    for col in raw.columns:
        try:
            uniq = raw[col].dropna().astype(str).str.strip().str.lower().unique()
            if set(uniq).issubset({"yes", "no"}):
                raw[col] = raw[col].astype(str).str.strip().str.lower().map({"yes": 1, "no": 0})
        except Exception:
            pass

    rename = {k: v for k, v in user_mapping.items() if v}
    df = raw.rename(columns=rename)

    missing = [c for c in ALL_REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns after mapping: {missing}")

    df = df[ALL_REQUIRED].copy()

    # Convert to numeric, drop unparseable rows
    for col in ALL_REQUIRED:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df.dropna(inplace=True)

    # Auto-scale each feature column to its expected range if wildly off
    scale_ranges = {
        "study_hours"    : (0, 15),
        "attendance"     : (0, 100),
        "previous_marks" : (0, 100),
        "sleep_hours"    : (0, 12),
        "assignments"    : (0, 10),
        "mock_score"     : (0, 100),
    }
    for col, (lo, hi) in scale_ranges.items():
        cmax = df[col].max()
        if cmax > hi * 1.5:   # e.g. Tutoring_Sessions up to 8 mapped to mock_score is fine; 800 is not
            df[col] = ((df[col] - df[col].min()) / (cmax - df[col].min())) * (hi - lo) + lo

    # Scale assignments 0-1 (Yes/No) up to 0-10 range
    if df["assignments"].max() <= 1:
        df["assignments"] = df["assignments"] * 10

    # Scale mock_score: Tutoring_Sessions is typically 0-8, scale to 0-100
    if df["mock_score"].max() <= 20:
        df["mock_score"] = ((df["mock_score"] - df["mock_score"].min()) /
                            max(df["mock_score"].max() - df["mock_score"].min(), 1)) * 100

    # Auto-scale final_marks to 0-100 if range is different
    fmax = df["final_marks"].max()
    fmin = df["final_marks"].min()
    if fmax > 100 or fmax <= 10:
        df["final_marks"] = ((df["final_marks"] - fmin) / (fmax - fmin)) * 100

    df["final_marks"] = df["final_marks"].clip(0, 100).round(1)

    info = (f"Loaded {len(df):,} rows from '{os.path.basename(filepath)}'  "
            f"| Mapped: {list(rename.values())}")
    return df, info


# ══════════════════════════════════════════════════════════════════
#  3.  COLUMN MAPPER DIALOG
# ══════════════════════════════════════════════════════════════════

class ColumnMapperDialog(tk.Toplevel):
    """
    Modal dialog shown when CSV columns cannot be fully auto-matched.
    Lets the user assign each required field to a CSV column.
    """

    def __init__(self, parent, raw_cols, auto_mapping):
        super().__init__(parent)
        self.title("Map CSV Columns  →  Required Fields")
        self.configure(bg=BG_DARK)
        self.resizable(False, False)
        self.grab_set()

        self.result   = None
        self.raw_cols = ["(skip)"] + raw_cols
        self.vars     = {}

        tk.Label(self, text="📂  Assign CSV columns to each required field",
                 font=FONT_H2, fg=TEXT_PRI, bg=BG_DARK, pady=10
                 ).pack(fill="x", padx=20)

        tk.Label(self,
                 text="Auto-matched fields are pre-filled. Adjust any mismatches below.",
                 font=FONT_SM, fg=TEXT_SEC, bg=BG_DARK
                 ).pack(padx=20, anchor="w")

        # Reverse map: internal -> raw
        rev = {v: k for k, v in auto_mapping.items()}

        grid = tk.Frame(self, bg=BG_CARD, padx=16, pady=12)
        grid.pack(fill="x", padx=20, pady=10)

        for ci, h in enumerate(["Required Field", "Your CSV Column", "Status"]):
            tk.Label(grid, text=h, font=FONT_H3, fg=ACCENT, bg=BG_CARD,
                     width=22, anchor="w"
                     ).grid(row=0, column=ci, padx=6, pady=4)

        self._status_labels = {}
        for ri, internal in enumerate(ALL_REQUIRED, start=1):
            label = internal.replace("_", " ").title()
            tk.Label(grid, text=label, font=FONT_BODY, fg=TEXT_PRI,
                     bg=BG_CARD, width=22, anchor="w"
                     ).grid(row=ri, column=0, padx=6, pady=3)

            var = tk.StringVar()
            default = rev.get(internal, "(skip)")
            var.set(default if default in self.raw_cols else "(skip)")
            self.vars[internal] = var

            cb = ttk.Combobox(grid, textvariable=var, values=self.raw_cols,
                              width=24, state="readonly", font=FONT_BODY)
            cb.grid(row=ri, column=1, padx=6, pady=3)

            sl = tk.Label(grid, text="", font=FONT_SM, bg=BG_CARD, width=12)
            sl.grid(row=ri, column=2, padx=6)
            self._status_labels[internal] = sl
            self._refresh_row(internal)

            cb.bind("<<ComboboxSelected>>",
                    lambda e, n=internal: self._refresh_row(n))

        btn_row = tk.Frame(self, bg=BG_DARK)
        btn_row.pack(pady=12)
        tk.Button(btn_row, text="✔  Confirm & Load", font=FONT_H3,
                  fg="#fff", bg=SUCCESS, activebackground="#2ea043",
                  relief="flat", padx=16, pady=8, cursor="hand2",
                  command=self._confirm
                  ).pack(side="left", padx=8)
        tk.Button(btn_row, text="✖  Cancel", font=FONT_H3,
                  fg="#fff", bg=DANGER, activebackground="#da3633",
                  relief="flat", padx=16, pady=8, cursor="hand2",
                  command=self.destroy
                  ).pack(side="left", padx=8)

        self.wait_window()

    def _refresh_row(self, internal):
        val = self.vars[internal].get()
        lbl = self._status_labels[internal]
        if val != "(skip)":
            lbl.config(text="✔  mapped", fg=SUCCESS)
        else:
            lbl.config(text="⚠  skipped", fg=WARNING)

    def _confirm(self):
        mapping = {}
        for internal, var in self.vars.items():
            chosen = var.get()
            if chosen != "(skip)":
                mapping[chosen] = internal
        self.result = mapping
        self.destroy()


# ══════════════════════════════════════════════════════════════════
#  4.  MODEL MANAGER
# ══════════════════════════════════════════════════════════════════

class ModelManager:
    """Trains, stores, and evaluates both ML models."""

    def __init__(self, df):
        self.df     = df
        self.scaler = StandardScaler()
        self.models = {}
        self.metrics = {}
        self._train()

    def _train(self):
        X = self.df[FEATURE_COLS].values
        y = self.df["final_marks"].values

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        X_train_sc = self.scaler.fit_transform(X_train)
        X_test_sc  = self.scaler.transform(X_test)

        for name, model in [
            ("Linear Regression", LinearRegression()),
            ("Decision Tree",     DecisionTreeRegressor(max_depth=6, random_state=42)),
        ]:
            if name == "Linear Regression":
                model.fit(X_train_sc, y_train)
                preds = model.predict(X_test_sc)
            else:
                model.fit(X_train, y_train)
                preds = model.predict(X_test)

            preds = np.clip(preds, 0, 100)
            self.models[name]  = model
            self.metrics[name] = {
                "R²"  : round(r2_score(y_test, preds), 4),
                "RMSE": round(np.sqrt(mean_squared_error(y_test, preds)), 4),
            }

        self.X_test    = X_test
        self.X_test_sc = X_test_sc
        self.y_test    = y_test

    def predict(self, features, model_name):
        arr = np.array(features).reshape(1, -1)
        if model_name == "Linear Regression":
            pred = self.models[model_name].predict(self.scaler.transform(arr))[0]
        else:
            pred = self.models[model_name].predict(arr)[0]
        return float(np.clip(pred, 0, 100))

    def get_feature_importance(self, model_name):
        if model_name == "Decision Tree":
            return self.models[model_name].feature_importances_
        coefs = np.abs(self.models[model_name].coef_)
        return coefs / coefs.sum()

    def get_correlation(self):
        return self.df[FEATURE_COLS + ["final_marks"]].corr()


# ══════════════════════════════════════════════════════════════════
#  5.  GRADE & INSIGHT HELPERS
# ══════════════════════════════════════════════════════════════════

def get_grade(marks):
    if marks >= 90: return "A+", "#00c896"
    if marks >= 80: return "A",  "#4caf50"
    if marks >= 70: return "B",  "#8bc34a"
    if marks >= 60: return "C",  "#ffc107"
    if marks >= 50: return "D",  "#ff9800"
    return "F", "#f44336"

def build_insights(features, predicted):
    tips = []
    if features["study_hours"]    < 4:  tips.append("📚  Aim for 4–6 study hours/day to boost marks.")
    if features["attendance"]     < 75: tips.append("🏫  Attendance below 75% — attend more classes.")
    if features["sleep_hours"]    < 6:  tips.append("😴  Less than 6 hrs of sleep hurts focus; aim for 7–8.")
    if features["assignments"]    < 5:  tips.append("📝  Complete more assignments to solidify concepts.")
    if features["mock_score"]     < 50: tips.append("🎯  Low mock score — practise past papers.")
    if features["previous_marks"] < 50: tips.append("📈  Seek help to close fundamental knowledge gaps.")
    if not tips:
        tips.append("✅  Great habits! Maintain consistency for top performance.")
    return tips


# ══════════════════════════════════════════════════════════════════
#  6.  SLIDER ROW WIDGET
# ══════════════════════════════════════════════════════════════════

class SliderRow:
    def __init__(self, parent, label, from_, to, resolution, default, unit=""):
        self.var        = tk.DoubleVar(value=default)
        self.resolution = resolution
        self.unit       = unit

        frame = tk.Frame(parent, bg=BG_CARD)
        frame.pack(fill="x", padx=12, pady=4)

        tk.Label(frame, text=label, font=FONT_BODY, fg=TEXT_PRI,
                 bg=BG_CARD, width=18, anchor="w").pack(side="left")

        self.slider = ttk.Scale(frame, from_=from_, to=to, orient="horizontal",
                                variable=self.var, length=260,
                                command=lambda _: self._snap())
        self.slider.pack(side="left", padx=(4, 8))

        self.val_lbl = tk.Label(frame, text=f"{default:.1f}{unit}",
                                font=FONT_MONO, fg=ACCENT, bg=BG_LIGHT,
                                width=8, relief="flat", padx=4, pady=2)
        self.val_lbl.pack(side="left")

    def _snap(self):
        v = round(self.var.get() / self.resolution) * self.resolution
        self.var.set(v)
        self.val_lbl.config(text=f"{v:.1f}{self.unit}")

    def get(self):
        return round(self.var.get() / self.resolution) * self.resolution


# ══════════════════════════════════════════════════════════════════
#  7.  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════

class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Student Performance Prediction  •  ML Dashboard")
        self.configure(bg=BG_DARK)
        self.geometry("1280x820")
        self.minsize(1100, 720)
        self.resizable(True, True)

        self.df          = generate_dataset(800)
        self.dataset_src = "Synthetic (800 samples)"
        self.model_var   = tk.StringVar(value="Linear Regression")
        self.manager     = ModelManager(self.df)

        self._build_header()
        self._build_body()

        # ── Auto-load default Kaggle CSV if it exists ────────────
        if os.path.isfile(DEFAULT_CSV_PATH):
            self.after(200, lambda: self._load_csv_from_path(DEFAULT_CSV_PATH))
            self._status(f"Auto-loading: {os.path.basename(DEFAULT_CSV_PATH)} …")
        else:
            self._status(f"Ready  •  Using {self.dataset_src}  •  Models trained ✓")

    # ── Header ──────────────────────────────────────────────────
    def _build_header(self):
        hdr = tk.Frame(self, bg=BG_CARD, height=56)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="🎓  Student Performance Prediction",
                 font=FONT_H1, fg=TEXT_PRI, bg=BG_CARD
                 ).pack(side="left", padx=20)

        # Upload Kaggle CSV button
        tk.Button(
            hdr, text="📂  Upload Kaggle CSV",
            font=FONT_BODY, fg=UPLOAD_FG, bg=UPLOAD_BG,
            activebackground="#2a3a2a", activeforeground=SUCCESS,
            relief="flat", padx=14, pady=6, cursor="hand2",
            command=self._upload_csv
        ).pack(side="right", padx=16, pady=8)

        self.ds_badge = tk.Label(hdr, text=f"Dataset: {self.dataset_src}",
                                  font=FONT_SM, fg=TEXT_SEC, bg=BG_CARD)
        self.ds_badge.pack(side="right", padx=6)

    # ── Body ─────────────────────────────────────────────────────
    def _build_body(self):
        body = tk.Frame(self, bg=BG_DARK)
        body.pack(fill="both", expand=True, padx=12, pady=(8, 4))

        left = tk.Frame(body, bg=BG_DARK, width=410)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        self._build_input_panel(left)
        self._build_model_selector(left)
        self._build_predict_btn(left)
        self._build_result_panel(left)

        right = tk.Frame(body, bg=BG_DARK)
        right.pack(side="left", fill="both", expand=True)
        self._build_chart_tabs(right)

        self.status_var = tk.StringVar()
        tk.Label(self, textvariable=self.status_var, font=FONT_SM,
                 fg=TEXT_SEC, bg=BG_DARK, anchor="w", padx=14
                 ).pack(fill="x", side="bottom", pady=2)

    # ── Input Panel ─────────────────────────────────────────────
    def _build_input_panel(self, parent):
        card = self._card(parent, "📋  Input Features")
        self.sliders = {}
        for key, label in zip(FEATURE_COLS, FEATURE_LABELS):
            lo, hi, res, default, unit = FEATURE_RANGES[key]
            self.sliders[key] = SliderRow(card, label, lo, hi, res, default, unit)

    # ── Model Selector ───────────────────────────────────────────
    def _build_model_selector(self, parent):
        card = self._card(parent, "⚙️  Algorithm")
        row  = tk.Frame(card, bg=BG_CARD)
        row.pack(fill="x", padx=12, pady=6)

        for name in ("Linear Regression", "Decision Tree"):
            tk.Radiobutton(
                row, text=name, variable=self.model_var, value=name,
                font=FONT_BODY, fg=TEXT_PRI, bg=BG_CARD,
                activebackground=BG_CARD, activeforeground=ACCENT,
                selectcolor=BG_LIGHT, indicatoron=0, relief="flat",
                padx=14, pady=6, cursor="hand2",
                command=self._on_model_change
            ).pack(side="left", padx=(0, 6))

        self.metric_frame = tk.Frame(card, bg=BG_CARD)
        self.metric_frame.pack(fill="x", padx=12, pady=(0, 8))
        self._refresh_metrics()

    def _refresh_metrics(self):
        for w in self.metric_frame.winfo_children():
            w.destroy()
        m = self.manager.metrics[self.model_var.get()]
        for label, colour in [(f"R² = {m['R²']:.4f}", SUCCESS),
                               (f"RMSE = {m['RMSE']:.2f}", WARNING)]:
            tk.Label(self.metric_frame, text=label, font=FONT_MONO,
                     fg=colour, bg=BG_LIGHT, padx=10, pady=4
                     ).pack(side="left", padx=(0, 6))

    def _on_model_change(self):
        self._refresh_metrics()
        self._update_charts()

    # ── Predict Button ───────────────────────────────────────────
    def _build_predict_btn(self, parent):
        tk.Button(parent, text="▶  Predict Performance",
                  font=FONT_H2, fg="#fff", bg=ACCENT,
                  activebackground="#1f6feb", activeforeground="#fff",
                  relief="flat", padx=20, pady=10, cursor="hand2",
                  command=self._predict
                  ).pack(fill="x", pady=(6, 0))

    # ── Result Panel ─────────────────────────────────────────────
    def _build_result_panel(self, parent):
        card = self._card(parent, "📊  Prediction Result")
        row  = tk.Frame(card, bg=BG_CARD)
        row.pack(pady=(4, 0))

        self.score_lbl = tk.Label(row, text="—", font=FONT_BIG,
                                   fg=ACCENT, bg=BG_CARD)
        self.score_lbl.pack(side="left", padx=(12, 4))

        self.grade_lbl = tk.Label(row, text="", font=("Segoe UI", 28, "bold"),
                                   fg=TEXT_SEC, bg=BG_CARD)
        self.grade_lbl.pack(side="left", padx=4)

        self.insight_text = tk.Text(
            card, height=5, font=FONT_SM, fg=TEXT_PRI, bg=BG_LIGHT,
            relief="flat", wrap="word", padx=8, pady=6,
            state="disabled", borderwidth=0
        )
        self.insight_text.pack(fill="x", padx=12, pady=(6, 10))

    # ── Chart Tabs ───────────────────────────────────────────────
    def _build_chart_tabs(self, parent):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook",     background=BG_DARK,  borderwidth=0)
        style.configure("TNotebook.Tab", background=BG_LIGHT, foreground=TEXT_SEC,
                        padding=[14, 6], font=FONT_BODY)
        style.map("TNotebook.Tab",
                  background=[("selected", BG_CARD)],
                  foreground=[("selected", ACCENT)])

        self.nb = ttk.Notebook(parent)
        self.nb.pack(fill="both", expand=True)

        self.scatter_frame    = tk.Frame(self.nb, bg=BG_CARD)
        self.importance_frame = tk.Frame(self.nb, bg=BG_CARD)
        self.heatmap_frame    = tk.Frame(self.nb, bg=BG_CARD)
        self.avp_frame        = tk.Frame(self.nb, bg=BG_CARD)
        self.preview_frame    = tk.Frame(self.nb, bg=BG_CARD)

        self.nb.add(self.scatter_frame,    text="📈 Study Hours vs Marks")
        self.nb.add(self.importance_frame, text="📊 Feature Importance")
        self.nb.add(self.heatmap_frame,    text="🔥 Correlation Heatmap")
        self.nb.add(self.avp_frame,        text="🎯 Actual vs Predicted")
        self.nb.add(self.preview_frame,    text="🗂️  Dataset Preview")

        self._update_charts()
        self._draw_dataset_preview()

    # ══════════════════════════════════════════════════════════════
    #  CSV UPLOAD WORKFLOW
    # ══════════════════════════════════════════════════════════════

    def _upload_csv(self):
        """Opens file dialog (pre-set to default path) and loads CSV."""
        # Pre-fill initial directory from default path if it exists
        init_dir  = os.path.dirname(DEFAULT_CSV_PATH) if os.path.isfile(DEFAULT_CSV_PATH) else "/"
        init_file = os.path.basename(DEFAULT_CSV_PATH) if os.path.isfile(DEFAULT_CSV_PATH) else ""

        filepath = filedialog.askopenfilename(
            title="Select Kaggle Student Dataset (CSV)",
            initialdir=init_dir,
            initialfile=init_file,
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not filepath:
            return
        self._load_csv_from_path(filepath)

    def _load_csv_from_path(self, filepath):
        """
        Fully automatic CSV load — NO manual mapping dialog ever shown.

        Strategy (tried in order until all 7 columns are resolved):
          1. Synonym dictionary (KAGGLE_SYNONYM_MAP) — handles 100+ name variants
          2. Numeric-column best-fit — picks the unmapped numeric column whose
             value range best matches the missing internal field
          3. Synthetic fill — generates the missing column from a formula so the
             app always loads, even with partial datasets
        """
        # ── Step 1: Read raw CSV ─────────────────────────────────
        try:
            raw = pd.read_csv(filepath)
        except Exception as e:
            messagebox.showerror("Read Error", f"Could not read CSV:\n{e}")
            return

        raw_cols     = list(raw.columns)

        # ── Try DIRECT_MAPPING first (exact match for this dataset) ──
        direct_hit = all(col in raw_cols for col in DIRECT_MAPPING.keys())
        if direct_hit:
            auto_mapping = dict(DIRECT_MAPPING)   # perfect match, use immediately
        else:
            auto_mapping = auto_map_columns(raw_cols)   # fallback: synonym dict

        # ── Step 2: Smart numeric best-fit for still-missing fields ─
        mapped_targets = set(auto_mapping.values())
        missing        = [f for f in ALL_REQUIRED if f not in mapped_targets]

        if missing:
            # Collect numeric columns not yet claimed
            numeric_cols = [c for c in raw_cols
                            if pd.to_numeric(raw[c], errors="coerce").notna().sum() > len(raw)*0.5
                            and c not in auto_mapping]

            # Expected value ranges for each internal field
            field_ranges = {
                "study_hours"    : (0,   15),
                "attendance"     : (40,  100),
                "previous_marks" : (0,   100),
                "sleep_hours"    : (3,   12),
                "assignments"    : (0,   20),
                "mock_score"     : (0,   100),
                "final_marks"    : (0,   100),
            }

            for field in missing[:]:          # iterate copy so we can remove from list
                lo, hi = field_ranges[field]
                best_col, best_score = None, -1

                for col in numeric_cols:
                    series = pd.to_numeric(raw[col], errors="coerce").dropna()
                    if len(series) == 0:
                        continue
                    cmin, cmax = series.min(), series.max()
                    # Score = overlap of [cmin,cmax] with [lo,hi] normalised by field width
                    overlap = max(0, min(cmax, hi) - max(cmin, lo))
                    score   = overlap / max((hi - lo), 1)
                    if score > best_score:
                        best_score, best_col = score, col

                if best_col and best_score > 0.3:   # at least 30% range overlap
                    auto_mapping[best_col] = field
                    numeric_cols.remove(best_col)
                    missing.remove(field)

        # ── Step 3: Synthetic fill for any still-missing columns ──
        # Re-check after best-fit pass
        mapped_targets = set(auto_mapping.values())
        still_missing  = [f for f in ALL_REQUIRED if f not in mapped_targets]

        synthetic_defaults = {
            "study_hours"    : 5.0,
            "attendance"     : 75.0,
            "previous_marks" : 65.0,
            "sleep_hours"    : 7.0,
            "assignments"    : 6.0,
            "mock_score"     : 60.0,
            "final_marks"    : None,   # must exist — can't synthesise target
        }

        filled_cols = []
        for field in still_missing:
            if field == "final_marks":
                # Can't fabricate the target — show a clear error
                col_list = "\n".join(f"  • {c}" for c in raw_cols)
                messagebox.showerror(
                    "Target Column Not Found",
                    f"Could not find the final score / exam score column.\n\n"
                    f"Your CSV columns are:\n{col_list}\n\n"
                    f"👉 Recommended: Download 'Student Performance Factors'\n"
                    f"   from Kaggle (link in status bar) — it works directly."
                )
                self._status("❌  Load failed — target column not found. "
                             "Try: kaggle.com/datasets/lainguyn123/student-performance-factors")
                return
            else:
                # Fill with a sensible constant — better than crashing
                raw[field] = synthetic_defaults[field]
                auto_mapping[field] = field   # already named correctly
                filled_cols.append(field)

        if filled_cols:
            self._status(f"⚠  Filled missing columns with defaults: {filled_cols} — consider a better dataset")

        # ── Step 4: Load & prepare ────────────────────────────────
        try:
            df, info = load_and_prepare_csv(filepath, auto_mapping)
        except ValueError as e:
            messagebox.showerror("Column Error", str(e))
            return
        except Exception as e:
            messagebox.showerror("Load Error", f"Unexpected error:\n{e}")
            return

        if len(df) < 50:
            messagebox.showwarning(
                "Too Few Rows",
                f"Only {len(df)} valid rows found.\nNeed at least 50 to train."
            )
            return

        # Step 4: Retrain models on new dataset
        self._status(f"Training models on {os.path.basename(filepath)} ({len(df):,} rows)…")
        self.df          = df
        self.dataset_src = f"{os.path.basename(filepath)} ({len(df):,} rows)"
        self.manager     = ModelManager(self.df)

        self.ds_badge.config(text=f"Dataset: {self.dataset_src}", fg=SUCCESS)
        self._refresh_metrics()
        self._update_charts()
        self._draw_dataset_preview()
        self._status("✅  " + info)

        messagebox.showinfo(
            "Dataset Loaded Successfully! 🎉",
            f"Loaded {len(df):,} rows\n"
            f"Source: {os.path.basename(filepath)}\n\n"
            f"Both models have been retrained.\n"
            f"R² (LR): {self.manager.metrics['Linear Regression']['R²']}\n"
            f"R² (DT): {self.manager.metrics['Decision Tree']['R²']}"
        )

    # ══════════════════════════════════════════════════════════════
    #  DATASET PREVIEW TAB
    # ══════════════════════════════════════════════════════════════

    def _draw_dataset_preview(self):
        for w in self.preview_frame.winfo_children():
            w.destroy()

        df = self.df

        # Info bar
        info_bar = tk.Frame(self.preview_frame, bg=BG_LIGHT)
        info_bar.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(info_bar,
                 text=f"  📦  {len(df):,} rows  ×  {len(df.columns)} columns   "
                      f"|   Source: {self.dataset_src}",
                 font=FONT_BODY, fg=TEXT_PRI, bg=BG_LIGHT, pady=6
                 ).pack(side="left", padx=8)

        # Statistical summary table
        stats_frame = tk.Frame(self.preview_frame, bg=BG_CARD)
        stats_frame.pack(fill="x", padx=8, pady=(0, 4))
        tk.Label(stats_frame, text="  Statistical Summary",
                 font=FONT_H3, fg=ACCENT, bg=BG_CARD, pady=4
                 ).grid(row=0, column=0, columnspan=20, sticky="w", padx=8)

        summary = df.describe().round(2)
        cols    = list(summary.columns)
        rows_s  = list(summary.index)

        for ci, col in enumerate(cols):
            tk.Label(stats_frame, text=col, font=("Segoe UI", 9, "bold"),
                     fg=ACCENT, bg=BG_CARD, width=13, anchor="center"
                     ).grid(row=1, column=ci+1, padx=2, pady=2)

        for ri, stat in enumerate(rows_s):
            tk.Label(stats_frame, text=stat, font=("Segoe UI", 9, "bold"),
                     fg=TEXT_SEC, bg=BG_CARD, width=8, anchor="w"
                     ).grid(row=ri+2, column=0, padx=(10, 2), pady=1)
            for ci, col in enumerate(cols):
                val = summary.loc[stat, col]
                tk.Label(stats_frame, text=str(val), font=FONT_MONO,
                         fg=TEXT_PRI,
                         bg=BG_LIGHT if ri % 2 == 0 else BG_CARD,
                         width=13, anchor="center"
                         ).grid(row=ri+2, column=ci+1, padx=2, pady=1)

        # Scrollable raw data table
        tk.Label(self.preview_frame, text="  First 20 Rows",
                 font=FONT_H3, fg=ACCENT, bg=BG_DARK
                 ).pack(anchor="w", padx=12, pady=(8, 2))

        tbl_outer = tk.Frame(self.preview_frame, bg=BG_DARK)
        tbl_outer.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        vsb = ttk.Scrollbar(tbl_outer, orient="vertical")
        hsb = ttk.Scrollbar(tbl_outer, orient="horizontal")
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")

        tv = ttk.Treeview(tbl_outer, yscrollcommand=vsb.set,
                          xscrollcommand=hsb.set, height=10)
        vsb.config(command=tv.yview)
        hsb.config(command=tv.xview)
        tv.pack(fill="both", expand=True)

        tv["columns"] = list(df.columns)
        tv["show"]    = "headings"
        for col in df.columns:
            tv.heading(col, text=col)
            tv.column(col, width=110, anchor="center")

        ts = ttk.Style()
        ts.configure("Treeview",
                     background=BG_LIGHT, foreground=TEXT_PRI,
                     fieldbackground=BG_LIGHT, rowheight=22, font=FONT_SM)
        ts.configure("Treeview.Heading",
                     background=BG_CARD, foreground=ACCENT,
                     font=("Segoe UI", 9, "bold"))

        for _, row in df.head(20).iterrows():
            tv.insert("", "end", values=[str(round(v, 2)) for v in row])

    # ══════════════════════════════════════════════════════════════
    #  CHARTS
    # ══════════════════════════════════════════════════════════════

    def _update_charts(self):
        threading.Thread(target=self.__draw_all, daemon=True).start()

    def __draw_all(self):
        self.__draw_scatter()
        self.__draw_importance()
        self.__draw_heatmap()
        self.__draw_avp()

    def _embed_fig(self, fig, parent):
        for w in parent.winfo_children():
            w.destroy()
        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)

    def _dark_ax(self, fig, axes):
        fig.patch.set_facecolor(BG_CARD)
        for ax in axes:
            ax.set_facecolor(BG_LIGHT)
            ax.tick_params(colors=TEXT_SEC, labelsize=8)
            ax.xaxis.label.set_color(TEXT_SEC)
            ax.yaxis.label.set_color(TEXT_SEC)
            ax.title.set_color(TEXT_PRI)
            for spine in ax.spines.values():
                spine.set_edgecolor(BORDER)

    def __draw_scatter(self):
        fig, ax = plt.subplots(figsize=(5.5, 3.8), tight_layout=True)
        self._dark_ax(fig, [ax])
        ax.scatter(self.df["study_hours"], self.df["final_marks"],
                   alpha=0.45, s=18, color=ACCENT, edgecolors="none")
        m, b = np.polyfit(self.df["study_hours"], self.df["final_marks"], 1)
        xs = np.linspace(self.df["study_hours"].min(), self.df["study_hours"].max(), 100)
        ax.plot(xs, m*xs+b, color=ACCENT2, linewidth=2, label="Trend")
        ax.set_xlabel("Study Hours / Day", fontsize=9)
        ax.set_ylabel("Final Marks",       fontsize=9)
        ax.set_title("Study Hours vs Final Marks", fontsize=11, fontweight="bold")
        ax.legend(fontsize=8, facecolor=BG_LIGHT, edgecolor=BORDER, labelcolor=TEXT_PRI)
        self.after(0, self._embed_fig, fig, self.scatter_frame)

    def __draw_importance(self):
        imp     = self.manager.get_feature_importance(self.model_var.get())
        colours = [ACCENT if v >= np.median(imp) else TEXT_SEC for v in imp]
        fig, ax = plt.subplots(figsize=(5.5, 3.8), tight_layout=True)
        self._dark_ax(fig, [ax])
        bars = ax.barh(FEATURE_LABELS, imp, color=colours, edgecolor="none", height=0.55)
        for bar, val in zip(bars, imp):
            ax.text(val+0.005, bar.get_y()+bar.get_height()/2,
                    f"{val:.3f}", va="center", color=TEXT_PRI, fontsize=8)
        ax.set_xlabel("Importance Score", fontsize=9)
        ax.set_title(f"Feature Importance — {self.model_var.get()}", fontsize=11, fontweight="bold")
        ax.set_xlim(0, max(imp)*1.25)
        self.after(0, self._embed_fig, fig, self.importance_frame)

    def __draw_heatmap(self):
        corr   = self.manager.get_correlation()
        labels = FEATURE_LABELS + ["Final Marks"]
        fig, ax = plt.subplots(figsize=(5.8, 4.0), tight_layout=True)
        self._dark_ax(fig, [ax])
        im = ax.imshow(corr.values, cmap="RdYlGn", vmin=-1, vmax=1)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=7)
        ax.set_yticks(range(len(labels)))
        ax.set_yticklabels(labels, fontsize=7)
        for i in range(len(labels)):
            for j in range(len(labels)):
                v = corr.values[i, j]
                ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                        fontsize=6.5, color="black" if abs(v) < 0.6 else "white")
        cb = fig.colorbar(im, ax=ax, fraction=0.035)
        cb.ax.tick_params(colors=TEXT_SEC, labelsize=7)
        ax.set_title("Feature Correlation Heatmap", fontsize=11, fontweight="bold")
        self.after(0, self._embed_fig, fig, self.heatmap_frame)

    def __draw_avp(self):
        mgr  = self.manager
        name = self.model_var.get()
        if name == "Linear Regression":
            preds = np.clip(mgr.models[name].predict(mgr.X_test_sc), 0, 100)
        else:
            preds = np.clip(mgr.models[name].predict(mgr.X_test), 0, 100)
        fig, ax = plt.subplots(figsize=(5.5, 3.8), tight_layout=True)
        self._dark_ax(fig, [ax])
        ax.scatter(mgr.y_test, preds, alpha=0.5, s=18, color=ACCENT2, edgecolors="none")
        ax.plot([0, 100], [0, 100], "--", color=SUCCESS, linewidth=1.5, label="Perfect fit")
        ax.set_xlabel("Actual Marks",    fontsize=9)
        ax.set_ylabel("Predicted Marks", fontsize=9)
        ax.set_title(f"Actual vs Predicted — {name}", fontsize=11, fontweight="bold")
        ax.set_xlim(0, 100); ax.set_ylim(0, 100)
        ax.legend(fontsize=8, facecolor=BG_LIGHT, edgecolor=BORDER, labelcolor=TEXT_PRI)
        self.after(0, self._embed_fig, fig, self.avp_frame)

    # ══════════════════════════════════════════════════════════════
    #  PREDICTION
    # ══════════════════════════════════════════════════════════════

    def _predict(self):
        features   = {k: s.get() for k, s in self.sliders.items()}
        feat_list  = [features[k] for k in FEATURE_COLS]
        model_name = self.model_var.get()

        pred  = self.manager.predict(feat_list, model_name)
        grade, colour = get_grade(pred)
        tips  = build_insights(features, pred)

        self.score_lbl.config(text=f"{pred:.1f}", fg=colour)
        self.grade_lbl.config(text=f" Grade: {grade}", fg=colour)

        self.insight_text.config(state="normal")
        self.insight_text.delete("1.0", "end")
        for tip in tips:
            self.insight_text.insert("end", tip + "\n")
        self.insight_text.config(state="disabled")

        self._status(f"Predicted: {pred:.1f}/100  |  Grade: {grade}  "
                     f"|  Model: {model_name}  "
                     f"|  R²: {self.manager.metrics[model_name]['R²']}")

    # ── Helpers ───────────────────────────────────────────────────
    def _card(self, parent, title):
        outer = tk.Frame(parent, bg=BORDER, pady=1)
        outer.pack(fill="x", pady=(0, 6))
        inner = tk.Frame(outer, bg=BG_CARD)
        inner.pack(fill="x")
        tk.Label(inner, text=title, font=FONT_H3, fg=ACCENT,
                 bg=BG_CARD, anchor="w", padx=12, pady=6
                 ).pack(fill="x")
        tk.Frame(inner, bg=BORDER, height=1).pack(fill="x")
        return inner

    def _status(self, msg):
        try: self.status_var.set(msg)
        except: pass


# ══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = App()
    app.mainloop()
