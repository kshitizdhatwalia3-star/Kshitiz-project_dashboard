/* 
  Mazon (Amazon clone demo)
  Frontend: HTML/CSS/Vanilla JS
  Backend: Flask + SQLite (see app.py)
*/

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const API = {
  async get(path) {
    const res = await fetch(path, { credentials: "same-origin" });
    return await res.json();
  },
  async post(path, body) {
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(body || {}),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || "Request failed");
    return json;
  },
  async patch(path, body) {
    const res = await fetch(path, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(body || {}),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || "Request failed");
    return json;
  },
  async del(path) {
    const res = await fetch(path, { method: "DELETE", credentials: "same-origin" });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || "Request failed");
    return json;
  },
};

const Store = {
  // Guest cart (localStorage) only used when not logged in.
  getGuestCart() {
    try {
      return JSON.parse(localStorage.getItem("guest_cart") || "[]");
    } catch {
      return [];
    }
  },
  setGuestCart(items) {
    localStorage.setItem("guest_cart", JSON.stringify(items || []));
  },
  clearGuestCart() {
    localStorage.removeItem("guest_cart");
  },
};

const Money = {
  format(cents) {
    const v = (Number(cents) || 0) / 100;
    return v.toLocaleString(undefined, { style: "currency", currency: "USD" });
  },
};

function toast(title, msg) {
  const el = $("#toast");
  el.innerHTML = `<div class="toast__title">${escapeHtml(title)}</div><div class="toast__msg">${escapeHtml(
    msg || ""
  )}</div>`;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2600);
}

function escapeHtml(str) {
  return String(str || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function stars(rating) {
  const r = Math.max(0, Math.min(5, Number(rating || 0)));
  const full = Math.floor(r);
  const out = [];
  for (let i = 1; i <= 5; i++) {
    out.push(`<span class="${i <= full ? "star" : "starOff"}">★</span>`);
  }
  return `<span class="stars" aria-label="Rating ${r.toFixed(1)} out of 5">${out.join("")}</span>`;
}

// ---------- App State ----------
const State = {
  me: null,
  categories: [],
  productsCache: new Map(), // productId -> product
  lastSearch: { q: "", category: "", sort: "" },
};

async function loadMe() {
  const { user } = await API.get("/api/me");
  State.me = user;
  updateNavUser();
}

function updateNavUser() {
  const el = $("#navHello");
  if (State.me) {
    el.href = "#/profile";
    el.innerHTML = `<div class="nav__small">Hello, ${escapeHtml(State.me.name)}</div><div class="nav__big">Profile</div>`;
  } else {
    el.href = "#/login";
    el.innerHTML = `<div class="nav__small">Hello, sign in</div><div class="nav__big">Account</div>`;
  }
}

async function loadCategories() {
  const { categories } = await API.get("/api/categories");
  State.categories = categories;

  // Top category pills
  const links = $("#categoryLinks");
  links.innerHTML = categories
    .map((c) => `<a class="pill" href="#/category/${encodeURIComponent(c.slug)}">${escapeHtml(c.name)}</a>`)
    .join("");

  // Search category select
  const sel = $("#categorySelect");
  sel.innerHTML =
    `<option value="">All</option>` +
    categories.map((c) => `<option value="${escapeHtml(c.slug)}">${escapeHtml(c.name)}</option>`).join("");
}

async function getCartItems() {
  if (State.me) {
    return (await API.get("/api/cart")).items || [];
  }
  // Guest cart only stores {product_id, quantity}. Enrich it with live product data.
  const guest = Store.getGuestCart();
  if (!guest.length) return [];
  const enriched = await Promise.all(
    guest.map(async (g) => {
      const cached = State.productsCache.get(String(g.product_id));
      const p = cached ? cached : (await API.get(`/api/products/${g.product_id}`)).product;
      State.productsCache.set(String(p.id), p);
      return {
        product_id: p.id,
        quantity: Number(g.quantity || 1),
        title: p.title,
        price_cents: p.price_cents,
        image_key: p.image_key,
        image_url: p.image_url,
        rating: p.rating,
        rating_count: p.rating_count,
      };
    })
  );
  return enriched;
}

async function setCartCount() {
  const items = await getCartItems();
  const count = items.reduce((a, it) => a + Number(it.quantity || 0), 0);
  $("#cartCount").textContent = String(count);
}

// Merge guest cart into user cart after login/signup.
async function mergeGuestCartToUser() {
  const guest = Store.getGuestCart();
  if (!guest.length) return;
  for (const it of guest) {
    await API.post("/api/cart/items", { product_id: it.product_id, quantity: it.quantity });
  }
  Store.clearGuestCart();
}

// ---------- Routes / Rendering ----------
function route() {
  const hash = location.hash || "#/";
  const [, r1, r2, r3] = hash.split("/");
  const app = $("#app");

  // Keep search state in sync with UI
  $("#categorySelect").value = State.lastSearch.category || "";
  $("#searchInput").value = State.lastSearch.q || "";

  if (!r1 || r1 === "#") return renderHome(app);

  switch (r1) {
    case "#":
      return renderHome(app);
    case "#?":
      return renderHome(app);
    default:
      break;
  }

  const page = r1.replace("#", "");
  if (page === "") return renderHome(app);

  if (page === "category") return renderCategory(app, r2);
  if (page === "product") return renderProduct(app, r2);
  if (page === "cart") return renderCart(app);
  if (page === "checkout") return renderCheckout(app);
  if (page === "login") return renderLogin(app);
  if (page === "signup") return renderSignup(app);
  if (page === "forgot") return renderForgot(app);
  if (page === "profile") return renderProfile(app);
  if (page === "orders") return renderOrders(app);

  return renderNotFound(app);
}

function renderHome(app) {
  const cats = State.categories;
  app.innerHTML = `
    <section class="hero">
      <div class="heroCard">
        <h1 class="heroTitle">Shop smart. Demo fast.</h1>
        <p class="heroSub">
          A professional Amazon-style clone with categories, search, product pages, cart, checkout,
          signup/login, and order history — powered by Flask + SQLite.
        </p>
        <div class="hr"></div>
        <div class="toolbar">
          <select id="sortSelect" class="select" aria-label="Sort">
            <option value="">Sort: Featured</option>
            <option value="price-asc">Price: Low → High</option>
            <option value="price-desc">Price: High → Low</option>
            <option value="rating-desc">Rating: High → Low</option>
          </select>
          <button class="btn btnPrimary" id="shopAllBtn">Browse products</button>
        </div>
      </div>
      <div class="heroAside">
        <div class="kpi">
          <div class="kpiBox">
            <div class="kpiLabel">Categories</div>
            <div class="kpiValue">${cats.length}</div>
          </div>
          <div class="kpiBox">
            <div class="kpiLabel">Cart</div>
            <div class="kpiValue">Real-time</div>
          </div>
          <div class="kpiBox">
            <div class="kpiLabel">Backend</div>
            <div class="kpiValue">SQLite</div>
          </div>
          <div class="kpiBox">
            <div class="kpiLabel">Auth</div>
            <div class="kpiValue">Session</div>
          </div>
        </div>
        <div class="hr"></div>
        <div class="muted">Tip: search “watch”, “lamp”, “headphones”…</div>
      </div>
    </section>

    <div class="sectionTitle">
      <h2>Shop by Category</h2>
      <div class="muted">Pick a category to see products</div>
    </div>
    <div class="grid">
      ${cats
        .map(
          (c) => `
          <a class="card" href="#/category/${encodeURIComponent(c.slug)}">
            <img class="card__img" src="/assets/img/${escapeHtml(c.slug)}.svg?text=${encodeURIComponent(
            c.name
          )}" alt="${escapeHtml(c.name)}"/>
            <div class="card__body">
              <div class="card__title">${escapeHtml(c.name)}</div>
              <div class="card__meta">${stars(4.6)} <span>${escapeHtml(c.slug)}</span></div>
              <div class="btnRow">
                <button class="btn btnPrimary" type="button">Explore</button>
              </div>
            </div>
          </a>
        `
        )
        .join("")}
    </div>
  `;

  $("#shopAllBtn").onclick = () => {
    const sort = $("#sortSelect").value;
    State.lastSearch.sort = sort;
    State.lastSearch.category = "";
    location.hash = "#/category/all";
  };
}

async function renderCategory(app, slugRaw) {
  const slug = decodeURIComponent(slugRaw || "");
  const sort = State.lastSearch.sort || "";
  const categoryParam = slug === "all" ? "" : slug;
  const q = State.lastSearch.q || "";

  const { products } = await API.get(
    `/api/products?category=${encodeURIComponent(categoryParam)}&q=${encodeURIComponent(
      q
    )}&sort=${encodeURIComponent(sort)}`
  );
  products.forEach((p) => State.productsCache.set(String(p.id), p));

  const title = slug === "all" ? "All Products" : State.categories.find((c) => c.slug === slug)?.name || "Category";

  app.innerHTML = `
    <div class="sectionTitle">
      <h2>${escapeHtml(title)}</h2>
      <div class="toolbar">
        <select id="sortSelect" class="select" aria-label="Sort">
          <option value="">Sort: Featured</option>
          <option value="price-asc">Price: Low → High</option>
          <option value="price-desc">Price: High → Low</option>
          <option value="rating-desc">Rating: High → Low</option>
        </select>
        <div class="muted">${products.length} items</div>
      </div>
    </div>
    <div class="grid">
      ${products.map(productCard).join("")}
    </div>
  `;

  $("#sortSelect").value = sort;
  $("#sortSelect").onchange = (e) => {
    State.lastSearch.sort = e.target.value;
    route();
  };

  bindAddToCartButtons();
}

function productCard(p) {
  return `
    <div class="card">
      <a href="#/product/${p.id}">
        <img class="card__img" src="${escapeHtml(p.image_url)}" alt="${escapeHtml(
    p.title
  )}" onerror="this.onerror=null;this.src='/product-images/${escapeHtml(p.image_key || "")}.svg';" />
      </a>
      <div class="card__body">
        <a class="card__title" href="#/product/${p.id}">${escapeHtml(p.title)}</a>
        <div class="card__meta">
          ${stars(p.rating)} <span>(${Number(p.rating_count || 0).toLocaleString()})</span>
        </div>
        <div class="price">${Money.format(p.price_cents)}</div>
        <div class="btnRow">
          <button class="btn" data-action="view" data-id="${p.id}">Details</button>
          <button class="btn btnPrimary" data-action="add" data-id="${p.id}">Add to Cart</button>
        </div>
      </div>
    </div>
  `;
}

function bindAddToCartButtons() {
  $$("button[data-action='add']").forEach((b) => {
    b.onclick = async () => {
      const id = b.getAttribute("data-id");
      await addToCart(Number(id), 1);
    };
  });
  $$("button[data-action='view']").forEach((b) => {
    b.onclick = () => (location.hash = `#/product/${b.getAttribute("data-id")}`);
  });
}

async function addToCart(productId, quantity) {
  try {
    if (State.me) {
      await API.post("/api/cart/items", { product_id: productId, quantity });
    } else {
      // Prevent duplicates: if exists, increment quantity.
      const cart = Store.getGuestCart();
      const found = cart.find((x) => Number(x.product_id) === Number(productId));
      if (found) found.quantity = Number(found.quantity || 0) + Number(quantity || 1);
      else cart.push({ product_id: productId, quantity: Number(quantity || 1) });
      Store.setGuestCart(cart);
    }
    await setCartCount();
    toast("Added to cart", "Item updated in your cart.");
  } catch (e) {
    toast("Could not add", e.message || "Please try again.");
  }
}

async function renderProduct(app, idRaw) {
  const id = Number(decodeURIComponent(idRaw || "0"));
  const cached = State.productsCache.get(String(id));
  const data = cached ? { product: cached } : await API.get(`/api/products/${id}`);
  const p = data.product;

  app.innerHTML = `
    <div class="details">
      <div class="panel">
        <img class="details__img" src="${escapeHtml(p.image_url)}" alt="${escapeHtml(
    p.title
  )}" onerror="this.onerror=null;this.src='/product-images/${escapeHtml(p.image_key || "")}.svg';"/>
      </div>
      <div class="panel">
        <div class="muted">${escapeHtml(p.category_name)}</div>
        <h2 style="margin:6px 0 8px;font-size:22px">${escapeHtml(p.title)}</h2>
        <div class="card__meta">${stars(p.rating)} <span>(${Number(p.rating_count || 0).toLocaleString()})</span></div>
        <div class="hr"></div>
        <div class="price" style="font-size:22px">${Money.format(p.price_cents)}</div>
        <p class="muted" style="line-height:1.6">${escapeHtml(p.description)}</p>
        <div class="hr"></div>
        <div class="formRow">
          <div class="field">
            <label>Quantity</label>
            <input id="qtyInput" type="number" min="1" value="1" />
          </div>
          <div class="field">
            <label>&nbsp;</label>
            <button id="addBtn" class="btn btnPrimary" style="width:100%">Add to Cart</button>
          </div>
        </div>
        <div class="muted" style="margin-top:10px">
          ${State.me ? "Saved to your account cart." : "Tip: sign in to save your cart & orders."}
        </div>
      </div>
    </div>
  `;

  $("#addBtn").onclick = async () => {
    const qty = Math.max(1, Number($("#qtyInput").value || 1));
    await addToCart(id, qty);
  };
}

async function renderCart(app) {
  const items = await getCartItems();
  const isEmpty = !items.length;
  const total = items.reduce((a, it) => a + Number(it.price_cents || 0) * Number(it.quantity || 0), 0);

  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Your Cart</h2>
      <div class="muted">${State.me ? "Saved to your account" : "Guest cart (local only)"}</div>
    </div>

    ${isEmpty ? `<div class="panel">Your cart is empty. <a class="link" href="#/">Shop now</a>.</div>` : ""}

    ${!isEmpty ? `
      <div class="cartWrap">
        <div class="panel">
          <div style="display:grid;gap:10px" id="cartList">
            ${items.map(cartRow).join("")}
          </div>
        </div>
        <div class="panel">
          <div class="muted">Order summary</div>
          <div class="hr"></div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div style="font-weight:900">Total</div>
            <div class="price">${Money.format(total)}</div>
          </div>
          <div class="hr"></div>
          <button id="checkoutBtn" class="btn btnPrimary" style="width:100%">Proceed to Checkout</button>
          <div class="muted" style="margin-top:10px;font-size:12px">
            Duplicate items are prevented; quantities update in real-time.
          </div>
        </div>
      </div>
    ` : ""}
  `;

  if (!isEmpty) {
    $("#checkoutBtn").onclick = () => {
      if (!State.me) {
        toast("Sign in required", "Please log in to checkout and save your order history.");
        location.hash = "#/login";
        return;
      }
      location.hash = "#/checkout";
    };
  }

  // Bind quantity + remove
  $$("input[data-qty]").forEach((inp) => {
    inp.onchange = async () => {
      const productId = Number(inp.getAttribute("data-qty"));
      const qty = Math.max(1, Number(inp.value || 1));
      await updateQty(productId, qty);
      route();
    };
  });
  $$("button[data-remove]").forEach((btn) => {
    btn.onclick = async () => {
      const productId = Number(btn.getAttribute("data-remove"));
      await removeItem(productId);
      route();
    };
  });
}

function cartRow(it) {
  return `
    <div class="cartItem">
      <img class="cartItem__img" src="${escapeHtml(it.image_url || "")}" alt="${escapeHtml(
    it.title || ""
  )}" onerror="this.onerror=null;this.src='/product-images/${escapeHtml(it.image_key || "")}.svg';"/>
      <div>
        <div style="font-weight:950">${escapeHtml(it.title || "")}</div>
        <div class="muted" style="font-size:12px">${stars(it.rating)} <span>(${Number(it.rating_count || 0).toLocaleString()})</span></div>
        <div class="price" style="font-size:16px;margin-top:6px">${Money.format(it.price_cents)}</div>
      </div>
      <div style="display:grid;gap:8px;justify-items:end">
        <div class="qty">
          <span class="muted">Qty</span>
          <input type="number" min="1" value="${Number(it.quantity || 1)}" data-qty="${it.product_id}"/>
        </div>
        <button class="btn btnDanger" data-remove="${it.product_id}">Remove</button>
      </div>
    </div>
  `;
}

async function updateQty(productId, qty) {
  if (State.me) {
    await API.patch(`/api/cart/items/${productId}`, { quantity: qty });
  } else {
    const cart = Store.getGuestCart();
    const found = cart.find((x) => Number(x.product_id) === Number(productId));
    if (found) found.quantity = qty;
    Store.setGuestCart(cart);
  }
  await setCartCount();
}

async function removeItem(productId) {
  if (State.me) {
    await API.del(`/api/cart/items/${productId}`);
  } else {
    const cart = Store.getGuestCart().filter((x) => Number(x.product_id) !== Number(productId));
    Store.setGuestCart(cart);
  }
  await setCartCount();
  toast("Removed", "Item removed from your cart.");
}

async function renderCheckout(app) {
  if (!State.me) {
    location.hash = "#/login";
    return;
  }
  const items = await getCartItems();
  const total = items.reduce((a, it) => a + Number(it.price_cents || 0) * Number(it.quantity || 0), 0);
  if (!items.length) {
    app.innerHTML = `<div class="panel">Your cart is empty. <a class="link" href="#/">Shop now</a>.</div>`;
    return;
  }

  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Checkout</h2>
      <div class="muted">Dummy checkout (order will be saved)</div>
    </div>
    <div class="cartWrap">
      <div class="panel">
        <div class="muted">Shipping & Payment</div>
        <div class="hr"></div>
        <form id="checkoutForm" class="form">
          <div class="field">
            <label>Full name</label>
            <input name="shipping_name" placeholder="John Doe" required />
          </div>
          <div class="field">
            <label>Address</label>
            <textarea name="shipping_address" placeholder="Street, City, State, ZIP" required></textarea>
          </div>
          <div class="field">
            <label>Payment method</label>
            <select name="payment_method">
              <option>Card</option>
              <option>Cash on Delivery</option>
              <option>UPI</option>
            </select>
          </div>
          <button class="btn btnPrimary" type="submit">Place Order (${Money.format(total)})</button>
        </form>
      </div>
      <div class="panel">
        <div class="muted">Items</div>
        <div class="hr"></div>
        <div style="display:grid;gap:10px">
          ${items
            .map(
              (it) => `
            <div style="display:flex;justify-content:space-between;gap:10px">
              <div>
                <div style="font-weight:900">${escapeHtml(it.title)}</div>
                <div class="muted" style="font-size:12px">Qty ${Number(it.quantity)}</div>
              </div>
              <div style="font-weight:900">${Money.format(Number(it.price_cents) * Number(it.quantity))}</div>
            </div>
          `
            )
            .join("")}
        </div>
        <div class="hr"></div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:900">Total</div>
          <div class="price">${Money.format(total)}</div>
        </div>
      </div>
    </div>
  `;

  $("#checkoutForm").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    try {
      const res = await API.post("/api/checkout", payload);
      toast("Order placed", `Order #${res.order_id} saved to your profile.`);
      await setCartCount();
      location.hash = "#/orders";
    } catch (err) {
      toast("Checkout failed", err.message || "Please try again.");
    }
  };
}

function renderLogin(app) {
  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Login</h2>
      <div class="muted">Sign in to save your cart and orders</div>
    </div>
    <div class="panel">
      <form id="loginForm" class="form">
        <div class="field">
          <label>Email</label>
          <input name="email" type="email" placeholder="you@example.com" required />
        </div>
        <div class="field">
          <label>Password</label>
          <input name="password" type="password" placeholder="••••••" required />
        </div>
        <button class="btn btnPrimary" type="submit">Login</button>
        <div class="muted">
          <a class="link" href="#/forgot">Forgot password?</a>
          <span> · </span>
          No account? <a class="link" href="#/signup">Create one</a>.
        </div>
      </form>
    </div>
  `;

  $("#loginForm").onsubmit = async (e) => {
    e.preventDefault();
    const payload = Object.fromEntries(new FormData(e.target).entries());
    try {
      await API.post("/api/auth/login", payload);
      await loadMe();
      await mergeGuestCartToUser();
      await setCartCount();
      toast("Welcome back", "You are now logged in.");
      location.hash = "#/profile";
    } catch (err) {
      toast("Login failed", err.message || "Please try again.");
    }
  };
}

function renderForgot(app) {
  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Forgot password</h2>
      <div class="muted">Get an OTP on your email and set a new password</div>
    </div>
    <div class="panel">
      <form id="forgotForm" class="form">
        <div class="field">
          <label>Email</label>
          <input name="email" type="email" placeholder="you@example.com" required />
        </div>
        <div class="formRow">
          <button id="resetOtpBtn" class="btn" type="button">Send OTP</button>
          <div class="field">
            <label>OTP Code</label>
            <input name="otp_code" inputmode="numeric" placeholder="6-digit code" />
          </div>
        </div>
        <input type="hidden" name="otp_token" value="" />
        <div class="formRow">
          <div class="field">
            <label>New password</label>
            <input name="new_password" type="password" placeholder="Min 6 chars" required />
          </div>
          <div class="field">
            <label>Confirm password</label>
            <input name="confirm_password" type="password" placeholder="Repeat password" required />
          </div>
        </div>
        <button class="btn btnPrimary" type="submit">Reset password</button>
        <div class="muted">Back to <a class="link" href="#/login">Login</a>.</div>
      </form>
    </div>
  `;

  const form = $("#forgotForm");
  $("#resetOtpBtn").onclick = async () => {
    const email = form.email.value.trim();
    if (!email) return toast("Email required", "Enter your email first.");
    try {
      const res = await API.post("/api/auth/request-otp", { email, purpose: "reset" });
      form.otp_token.value = res.token;
      if (res.sent) toast("OTP sent", "Check your inbox for the reset code.");
      else toast("Dev OTP", `SMTP not set. OTP: ${res.dev_otp} (demo only)`);
    } catch (err) {
      toast("OTP failed", err.message || "Please try again.");
    }
  };

  form.onsubmit = async (e) => {
    e.preventDefault();
    const payload = Object.fromEntries(new FormData(e.target).entries());
    try {
      if (!payload.otp_token) throw new Error("Please click “Send OTP” first.");
      if (!payload.otp_code) throw new Error("Please enter the OTP code from your email.");
      if (payload.new_password !== payload.confirm_password) throw new Error("Passwords do not match.");

      await API.post("/api/auth/reset-password", {
        email: payload.email,
        otp_token: payload.otp_token,
        otp_code: payload.otp_code,
        new_password: payload.new_password,
      });
      toast("Password updated", "You can now log in with your new password.");
      location.hash = "#/login";
    } catch (err) {
      toast("Reset failed", err.message || "Please try again.");
    }
  };
}

function renderSignup(app) {
  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Create account</h2>
      <div class="muted">Signup with email OTP verification</div>
    </div>
    <div class="panel">
      <form id="signupForm" class="form">
        <div class="field">
          <label>Name</label>
          <input name="name" placeholder="Your name" required />
        </div>
        <div class="field">
          <label>Email</label>
          <input name="email" type="email" placeholder="you@example.com" required />
        </div>
        <div class="field">
          <label>Password (min 6 chars)</label>
          <input name="password" type="password" placeholder="••••••" required />
        </div>
        <div class="formRow">
          <button id="otpBtn" class="btn" type="button">Send OTP</button>
          <div class="field">
            <label>OTP Code</label>
            <input name="otp_code" inputmode="numeric" placeholder="6-digit code" />
          </div>
        </div>
        <input type="hidden" name="otp_token" value="" />
        <button class="btn btnPrimary" type="submit">Create account</button>
        <div class="muted">Already have an account? <a class="link" href="#/login">Login</a>.</div>
      </form>
    </div>
  `;

  const form = $("#signupForm");
  const otpBtn = $("#otpBtn");

  otpBtn.onclick = async () => {
    const email = form.email.value.trim();
    if (!email) {
      toast("Email required", "Enter your email first.");
      return;
    }
    try {
      const res = await API.post("/api/auth/request-otp", { email, purpose: "signup" });
      form.otp_token.value = res.token;
      if (res.sent) toast("OTP sent", "Check your inbox for the verification code.");
      else toast("Dev OTP", `SMTP not set. OTP: ${res.dev_otp} (demo only)`);
    } catch (err) {
      toast("OTP failed", err.message || "Please try again.");
    }
  };

  // Allow resend without any extra backend: just click "Send OTP" again (new token + code).
  otpBtn.textContent = "Send / Resend OTP";

  $("#signupForm").onsubmit = async (e) => {
    e.preventDefault();
    const payload = Object.fromEntries(new FormData(e.target).entries());
    try {
      // Ensure OTP was verified before creating the account (recommended flow).
      if (!payload.otp_token) throw new Error("Please click “Send OTP” first.");
      if (!payload.otp_code) throw new Error("Please enter the OTP code from your email.");
      await API.post("/api/auth/verify-otp", {
        email: payload.email,
        purpose: "signup",
        token: payload.otp_token,
        code: payload.otp_code,
      });

      await API.post("/api/auth/signup", payload);
      await loadMe();
      await mergeGuestCartToUser();
      await setCartCount();
      toast("Account created", "You are now logged in.");
      location.hash = "#/profile";
    } catch (err) {
      toast("Signup failed", err.message || "Please try again.");
    }
  };
}

async function renderProfile(app) {
  if (!State.me) {
    location.hash = "#/login";
    return;
  }
  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Profile</h2>
      <div class="toolbar">
        <button id="logoutBtn" class="btn">Logout</button>
      </div>
    </div>
    <div class="panel">
      <div style="display:grid;gap:8px">
        <div><span class="muted">Name:</span> <b>${escapeHtml(State.me.name)}</b></div>
        <div><span class="muted">Email:</span> <b>${escapeHtml(State.me.email)}</b></div>
        <div><span class="muted">Member since:</span> <b>${escapeHtml(State.me.created_at || "")}</b></div>
      </div>
      <div class="hr"></div>
      <div class="muted">Your order history is available in <a class="link" href="#/orders">Orders</a>.</div>
    </div>
  `;
  $("#logoutBtn").onclick = async () => {
    await API.post("/api/auth/logout", {});
    State.me = null;
    updateNavUser();
    await setCartCount();
    toast("Logged out", "You are now signed out.");
    location.hash = "#/";
  };
}

async function renderOrders(app) {
  if (!State.me) {
    app.innerHTML = `<div class="panel">Please <a class="link" href="#/login">log in</a> to view orders.</div>`;
    return;
  }
  const { orders } = await API.get("/api/orders");
  if (!orders.length) {
    app.innerHTML = `<div class="panel">No orders yet. <a class="link" href="#/">Shop now</a>.</div>`;
    return;
  }

  app.innerHTML = `
    <div class="sectionTitle">
      <h2>Orders</h2>
      <div class="muted">${orders.length} orders</div>
    </div>
    <div style="display:grid;gap:14px">
      ${orders
        .map(
          (o) => `
          <div class="panel">
            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
              <div>
                <div style="font-weight:950">Order #${o.id}</div>
                <div class="muted" style="font-size:12px">${escapeHtml(o.placed_at)} · ${escapeHtml(o.status)}</div>
              </div>
              <div class="price">${Money.format(o.total_cents)}</div>
            </div>
            <div class="hr"></div>
            <div class="muted" style="font-size:12px">
              Ship to: <b>${escapeHtml(o.shipping_name)}</b> — ${escapeHtml(o.shipping_address)}
            </div>
            <div class="hr"></div>
            <div style="display:grid;gap:10px">
              ${o.items
                .map(
                  (it) => `
                <div style="display:flex;justify-content:space-between;gap:10px">
                  <div>
                    <div style="font-weight:900">${escapeHtml(it.title)}</div>
                    <div class="muted" style="font-size:12px">Qty ${it.quantity}</div>
                  </div>
                  <div style="font-weight:900">${Money.format(it.price_cents * it.quantity)}</div>
                </div>
              `
                )
                .join("")}
            </div>
          </div>
        `
        )
        .join("")}
    </div>
  `;
}

function renderNotFound(app) {
  app.innerHTML = `<div class="panel">Page not found. <a class="link" href="#/">Go home</a>.</div>`;
}

// ---------- Search UX ----------
function bindTopSearch() {
  const run = () => {
    State.lastSearch.q = $("#searchInput").value.trim();
    State.lastSearch.category = $("#categorySelect").value.trim();
    State.lastSearch.sort = State.lastSearch.sort || "";
    const target = State.lastSearch.category ? `#/category/${State.lastSearch.category}` : "#/category/all";
    location.hash = target;
  };
  $("#searchBtn").onclick = run;
  $("#searchInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") run();
  });
  $("#categorySelect").onchange = () => run();
}

function bindMobileMenu() {
  $("#mobileMenuBtn").onclick = () => $("#categoryLinks").classList.toggle("open");
}

// ---------- Boot ----------
async function boot() {
  bindTopSearch();
  bindMobileMenu();
  await loadCategories();
  await loadMe();
  await setCartCount();
  window.addEventListener("hashchange", route);
  route();
}

boot().catch((e) => {
  $("#app").innerHTML = `<div class="panel">App failed to load: <span class="muted">${escapeHtml(
    e.message || String(e)
  )}</span></div>`;
});

