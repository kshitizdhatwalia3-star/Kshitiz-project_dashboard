## Production-ready Email OTP Auth (Node.js + Express + Redis + Nodemailer)

This service implements **secure email OTP verification** for **registration and login**:
- 6-digit OTP (crypto-secure)
- OTP stored in **Redis** with **TTL 5 minutes**
- OTP invalid after expiry or successful verification
- **Max 3 verification attempts**
- **Resend cooldown 30 seconds**
- **Rate limiting** per IP and per email/purpose (Redis)
- Email sending via **real SMTP** using **Nodemailer**
- Optional user storage in **MongoDB**

### Folder
`otp-auth/`

### Setup
1) Create `.env` (copy from `env.example.txt`)
2) Start Redis (and Mongo optionally):

```bash
docker compose up -d
```

3) Install deps + run:

```bash
npm install
npm run dev
```

### SMTP (real providers)
Use any real SMTP provider (examples):

#### Gmail (recommended for demos)
- `SMTP_HOST=smtp.gmail.com`
- `SMTP_PORT=587`
- `SMTP_SECURE=false`
- `SMTP_USER=your@gmail.com`
- `SMTP_PASS=<Gmail App Password>`

#### SendGrid
- `SMTP_HOST=smtp.sendgrid.net`
- `SMTP_PORT=587`
- `SMTP_SECURE=false`
- `SMTP_USER=apikey`
- `SMTP_PASS=<SENDGRID_API_KEY>`

#### AWS SES (SMTP)
Use SES SMTP credentials:
- `SMTP_HOST=email-smtp.<region>.amazonaws.com`
- `SMTP_PORT=587` (STARTTLS) or `465` (SSL)
- set `SMTP_SECURE` accordingly

### API

#### Request OTP (register/login)
`POST /auth/request-otp`

Body:
```json
{ "email": "user@example.com", "flow": "register" }
```

#### Verify OTP (register/login)
`POST /auth/verify-otp`

Body (register):
```json
{ "email": "user@example.com", "flow": "register", "name": "User", "otp": "123456" }
```

Body (login):
```json
{ "email": "user@example.com", "flow": "login", "otp": "123456" }
```

### Notes
- In production you would return a **JWT/session cookie** after `/auth/verify-otp`. This demo returns `{ authenticated: true }`.
- For correct IP-based rate limiting behind a proxy/load balancer, enable:
  - `app.set("trust proxy", 1)` in `src/index.js`

