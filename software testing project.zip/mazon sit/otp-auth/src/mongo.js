const { MongoClient } = require("mongodb");
const { config } = require("./config");

let client;

async function getMongo() {
  if (!config.mongodbUri) return null;
  if (client) return client;
  client = new MongoClient(config.mongodbUri);
  await client.connect();
  console.log("[mongo] connected");
  return client;
}

async function getUsersCollection() {
  const c = await getMongo();
  if (!c) return null;
  return c.db().collection("users");
}

module.exports = { getMongo, getUsersCollection };

