const nodemailer = require("nodemailer");
const { config } = require("./config");

let transporter;

function getTransporter() {
  if (transporter) return transporter;
  transporter = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.secure, // true for 465, false for 587 (STARTTLS)
    auth: { user: config.smtp.user, pass: config.smtp.pass },
  });
  return transporter;
}

async function sendOtpEmail({ to, otp, purpose }) {
  const subject =
    purpose === "login"
      ? `${config.appName} login code`
      : purpose === "reset"
        ? `${config.appName} password reset code`
        : `${config.appName} verification code`;

  const action =
    purpose === "login"
      ? "log in"
      : purpose === "reset"
        ? "reset your password"
        : "finish registration";

  const text = `Your OTP to ${action} is: ${otp}\n\nThis code expires in 5 minutes.\nIf you did not request this, ignore this email.`;

  const info = await getTransporter().sendMail({
    from: config.smtp.from,
    to,
    subject,
    text,
  });
  return info;
}

module.exports = { sendOtpEmail };

