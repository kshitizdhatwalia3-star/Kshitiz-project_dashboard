const { createClient } = require("redis");
const { config } = require("./config");

let client;

async function getRedis() {
  if (client) return client;
  client = createClient({ url: config.redisUrl });
  client.on("error", (err) => {
    console.error("[redis] error:", err);
  });
  await client.connect();
  console.log("[redis] connected");
  return client;
}

module.exports = { getRedis };

