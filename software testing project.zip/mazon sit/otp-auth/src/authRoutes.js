const express = require("express");
const { z } = require("zod");
const { normalizeEmail, getIp } = require("./security");
const { rateLimitOrThrow } = require("./rateLimit");
const { requestOtp, verifyOtp } = require("./otpService");
const { sendOtpEmail } = require("./emailer");
const { getUsersCollection } = require("./mongo");

const router = express.Router();

const RequestOtpSchema = z.object({
  email: z.string().email(),
  flow: z.enum(["register", "login"]).default("login"),
});

const VerifyOtpSchema = z.object({
  email: z.string().email(),
  flow: z.enum(["register", "login"]).default("login"),
  otp: z.string().regex(/^\d{6}$/),
  name: z.string().min(1).max(100).optional(), // only for register
});

function purposeFromFlow(flow) {
  return flow === "register" ? "register" : "login";
}

// Request OTP
router.post("/request-otp", async (req, res, next) => {
  try {
    const body = RequestOtpSchema.parse(req.body || {});
    const email = normalizeEmail(body.email);
    const ip = getIp(req);
    const purpose = purposeFromFlow(body.flow);

    // Abuse prevention: rate limit by IP + email
    await rateLimitOrThrow({
      key: `rl:otp:ip:${ip}`,
      windowSec: 60,
      limit: 20,
      errorMessage: "Too many OTP requests from this IP. Try again later.",
    });
    await rateLimitOrThrow({
      key: `rl:otp:email:${purpose}:${email}`,
      windowSec: 60,
      limit: 5,
      errorMessage: "Too many OTP requests for this email. Try again later.",
    });

    // Optional: check user existence in Mongo depending on flow
    const users = await getUsersCollection();
    if (users) {
      const existing = await users.findOne({ email }, { projection: { _id: 1 } });
      if (body.flow === "register" && existing) return res.status(409).json({ error: "Email already registered." });
      if (body.flow === "login" && !existing) return res.status(404).json({ error: "Account not found." });
    }

    const { otp } = await requestOtp({ purpose, email });
    await sendOtpEmail({ to: email, otp, purpose });
    return res.json({ ok: true, message: "OTP sent." });
  } catch (err) {
    return next(err);
  }
});

// Verify OTP (and create/login user if Mongo enabled)
router.post("/verify-otp", async (req, res, next) => {
  try {
    const body = VerifyOtpSchema.parse(req.body || {});
    const email = normalizeEmail(body.email);
    const purpose = purposeFromFlow(body.flow);

    await verifyOtp({ purpose, email, otp: body.otp });

    const users = await getUsersCollection();
    if (users) {
      if (body.flow === "register") {
        if (!body.name) return res.status(400).json({ error: "name is required for registration" });
        const existing = await users.findOne({ email }, { projection: { _id: 1 } });
        if (existing) return res.status(409).json({ error: "Email already registered." });
        await users.insertOne({ email, name: body.name, createdAt: new Date(), lastLoginAt: new Date() });
      } else {
        const existing = await users.findOne({ email }, { projection: { _id: 1 } });
        if (!existing) return res.status(404).json({ error: "Account not found." });
        await users.updateOne({ email }, { $set: { lastLoginAt: new Date() } });
      }
    }

    // Production: return a session/JWT. For demo, return success.
    return res.json({ ok: true, authenticated: true });
  } catch (err) {
    return next(err);
  }
});

module.exports = { authRouter: router };

