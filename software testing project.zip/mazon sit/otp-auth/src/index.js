const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const { config } = require("./config");
const { authRouter } = require("./authRoutes");

const app = express();

// If behind a reverse proxy (Render/NGINX/Heroku), enable this for correct IP rate limiting:
// app.set("trust proxy", 1);

app.use(helmet());
app.use(express.json({ limit: "64kb" }));

app.use(
  cors({
    origin(origin, cb) {
      if (!origin) return cb(null, true);
      if (!config.allowedOrigins.length) return cb(null, true);
      if (config.allowedOrigins.includes(origin)) return cb(null, true);
      return cb(new Error("CORS blocked"), false);
    },
    credentials: true,
  })
);

app.get("/health", (req, res) => res.json({ ok: true, name: config.appName }));

app.use("/auth", authRouter);

// Error handler (keeps responses clean)
app.use((err, req, res, next) => {
  const status = err.status || 400;
  const message = err.message || "Error";
  const meta = err.meta || undefined;
  if (config.nodeEnv !== "production") {
    console.error(err);
  }
  res.status(status).json({ error: message, ...(meta ? { meta } : {}) });
});

app.listen(config.port, () => {
  console.log(`[server] ${config.appName} listening on ${config.baseUrl}`);
});

