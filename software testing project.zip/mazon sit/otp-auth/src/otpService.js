const { config } = require("./config");
const { getRedis } = require("./redisClient");
const { generateOtp6, hmacOtp, timingSafeEqualHex } = require("./security");

const OTP_TTL_SEC = 5 * 60; // 5 minutes
const RESEND_COOLDOWN_SEC = 30; // 30 seconds
const MAX_ATTEMPTS = 3;

function otpKey(purpose, email) {
  return `otp:${purpose}:${email}`;
}
function cooldownKey(purpose, email) {
  return `otp:cooldown:${purpose}:${email}`;
}

async function requestOtp({ purpose, email }) {
  const r = await getRedis();

  // Resend cooldown (per purpose+email)
  const cdKey = cooldownKey(purpose, email);
  const cdTtl = await r.ttl(cdKey);
  if (cdTtl > 0) {
    const err = new Error(`Please wait ${cdTtl}s before resending OTP.`);
    err.status = 429;
    err.meta = { retry_after_seconds: cdTtl };
    throw err;
  }

  const otp = generateOtp6();
  const hash = hmacOtp(config.otpSecret, otp);
  const key = otpKey(purpose, email);

  // Store OTP hash + attempts with TTL
  await r
    .multi()
    .hSet(key, { hash, attempts: "0", createdAt: String(Date.now()) })
    .expire(key, OTP_TTL_SEC)
    .set(cdKey, "1", { EX: RESEND_COOLDOWN_SEC })
    .exec();

  return { otp, ttlSec: OTP_TTL_SEC };
}

async function verifyOtp({ purpose, email, otp }) {
  const r = await getRedis();
  const key = otpKey(purpose, email);
  const data = await r.hGetAll(key);
  if (!data || !data.hash) {
    const err = new Error("OTP expired or not found. Please request a new OTP.");
    err.status = 400;
    throw err;
  }

  const attempts = Number(data.attempts || 0);
  if (attempts >= MAX_ATTEMPTS) {
    const err = new Error("OTP locked due to too many failed attempts. Request a new OTP.");
    err.status = 429;
    throw err;
  }

  const candidateHash = hmacOtp(config.otpSecret, otp);
  const ok = timingSafeEqualHex(candidateHash, data.hash);
  if (!ok) {
    await r.hIncrBy(key, "attempts", 1);
    const left = Math.max(0, MAX_ATTEMPTS - (attempts + 1));
    const err = new Error(`Invalid OTP. Attempts left: ${left}`);
    err.status = 400;
    throw err;
  }

  // Success: invalidate OTP immediately
  await r.del(key);
  return { ok: true };
}

module.exports = {
  OTP_TTL_SEC,
  RESEND_COOLDOWN_SEC,
  MAX_ATTEMPTS,
  requestOtp,
  verifyOtp,
};

