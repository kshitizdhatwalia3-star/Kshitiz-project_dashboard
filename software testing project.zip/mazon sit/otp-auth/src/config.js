const dotenv = require("dotenv");

dotenv.config();

function required(name, value) {
  if (!value) throw new Error(`Missing required env var: ${name}`);
  return value;
}

const config = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: Number(process.env.PORT || 8080),
  appName: process.env.APP_NAME || "OTP Auth",
  baseUrl: process.env.BASE_URL || `http://localhost:${process.env.PORT || 8080}`,

  allowedOrigins: (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),

  otpSecret: required("OTP_SECRET", process.env.OTP_SECRET),

  redisUrl: required("REDIS_URL", process.env.REDIS_URL),

  smtp: {
    host: required("SMTP_HOST", process.env.SMTP_HOST),
    port: Number(required("SMTP_PORT", process.env.SMTP_PORT)),
    secure: String(process.env.SMTP_SECURE || "false").toLowerCase() === "true",
    user: required("SMTP_USER", process.env.SMTP_USER),
    pass: required("SMTP_PASS", process.env.SMTP_PASS),
    from: required("SMTP_FROM", process.env.SMTP_FROM),
  },

  mongodbUri: process.env.MONGODB_URI || "",
};

module.exports = { config };

