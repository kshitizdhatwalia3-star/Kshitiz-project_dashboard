const { getRedis } = require("./redisClient");

/**
 * Simple Redis rate limiter:
 * - increments key
 * - sets expiry on first hit
 * - blocks if count > limit
 */
async function rateLimitOrThrow({ key, windowSec, limit, errorMessage }) {
  const r = await getRedis();
  const n = await r.incr(key);
  if (n === 1) await r.expire(key, windowSec);
  if (n > limit) {
    const ttl = await r.ttl(key);
    const err = new Error(errorMessage || "Too many requests");
    err.status = 429;
    err.meta = { retry_after_seconds: Math.max(1, ttl) };
    throw err;
  }
}

module.exports = { rateLimitOrThrow };

