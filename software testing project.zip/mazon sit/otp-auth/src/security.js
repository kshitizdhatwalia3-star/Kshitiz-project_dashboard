const crypto = require("crypto");

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function generateOtp6() {
  // Cryptographically secure 6-digit OTP
  const n = crypto.randomInt(0, 1000000);
  return String(n).padStart(6, "0");
}

function hmacOtp(secret, otp) {
  return crypto.createHmac("sha256", secret).update(String(otp)).digest("hex");
}

function timingSafeEqualHex(a, b) {
  const aa = Buffer.from(String(a || ""), "hex");
  const bb = Buffer.from(String(b || ""), "hex");
  if (aa.length !== bb.length) return false;
  return crypto.timingSafeEqual(aa, bb);
}

function getIp(req) {
  // If behind proxy/load balancer, you should set: app.set("trust proxy", 1)
  const xf = req.headers["x-forwarded-for"];
  if (xf) return String(xf).split(",")[0].trim();
  return req.socket?.remoteAddress || "unknown";
}

module.exports = { normalizeEmail, generateOtp6, hmacOtp, timingSafeEqualHex, getIp };

