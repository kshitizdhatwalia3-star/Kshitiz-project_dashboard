from __future__ import annotations

import os
import secrets
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
import hashlib
from pathlib import Path
from typing import Any

from flask import (
    Flask,
    jsonify,
    redirect,
    request,
    send_from_directory,
    session,
)
from werkzeug.security import check_password_hash, generate_password_hash


ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "db" / "amazon_clone.sqlite"


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", static_url_path="/")
    # Demo secret key (fine for local demo). For real deployments, set an env var.
    app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    @app.get("/api/health")
    def health():
        return jsonify({"ok": True})

    # ---------- DB helpers ----------
    def db() -> sqlite3.Connection:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def require_auth() -> int:
        user_id = session.get("user_id")
        if not user_id:
            raise AuthError("Not logged in")
        return int(user_id)

    def now_utc() -> datetime:
        return datetime.now(timezone.utc)

    def dt_to_sql(dt: datetime) -> str:
        # Store UTC in a readable sqlite datetime string.
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    def sha256(s: str) -> str:
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    def send_email(to_email: str, subject: str, body: str) -> bool:
        """
        Sends OTP email via SMTP if configured.

        Configure via env vars:
          SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
          SMTP_SECURITY: 'starttls' (default) | 'ssl' | 'none'

        Returns True if sent, False if SMTP is not configured.
        """
        host = os.environ.get("SMTP_HOST")
        port = int(os.environ.get("SMTP_PORT", "0") or "0")
        user = os.environ.get("SMTP_USER")
        pw = os.environ.get("SMTP_PASS")
        from_email = os.environ.get("SMTP_FROM") or user
        security = (os.environ.get("SMTP_SECURITY") or "starttls").strip().lower()
        if not host or not port or not user or not pw or not from_email:
            return False

        msg = EmailMessage()
        msg["From"] = from_email
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.set_content(body)

        import smtplib

        if security == "ssl":
            with smtplib.SMTP_SSL(host, port) as smtp:
                smtp.login(user, pw)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(host, port) as smtp:
                if security == "starttls":
                    smtp.starttls()
                smtp.login(user, pw)
                smtp.send_message(msg)
        return True

    @app.get("/api/auth/smtp-status")
    def smtp_status():
        """
        Helps you debug OTP email sending configuration from the browser.
        """
        host = os.environ.get("SMTP_HOST")
        port = os.environ.get("SMTP_PORT")
        user = os.environ.get("SMTP_USER")
        from_email = os.environ.get("SMTP_FROM") or user
        security = (os.environ.get("SMTP_SECURITY") or "starttls").strip().lower()
        configured = bool(host and port and user and os.environ.get("SMTP_PASS") and from_email)
        return jsonify(
            {
                "configured": configured,
                "security": security,
                "host": host,
                "port": port,
                "user": user,
                "from": from_email,
            }
        )

    # ---------- Errors ----------
    @dataclass
    class AuthError(Exception):
        message: str

    @app.errorhandler(AuthError)
    def handle_auth_error(e: AuthError):
        return jsonify({"error": e.message}), 401

    # ---------- Auth ----------
    @app.post("/api/auth/request-otp")
    def request_otp():
        """
        Request an OTP for email verification.
        For demo: if SMTP is not configured, OTP is returned in the response as `dev_otp`.
        """
        data = request.get_json(force=True, silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        purpose = (data.get("purpose") or "signup").strip().lower()
        if not email or "@" not in email:
            return jsonify({"error": "Valid email is required."}), 400
        if purpose not in ("signup", "reset"):
            return jsonify({"error": "Invalid purpose."}), 400

        # For signup, prevent sending OTP for an email that already exists.
        # For reset, require that the email exists.
        with db() as conn:
            existing = conn.execute("SELECT 1 FROM users WHERE email = ?;", (email,)).fetchone()
        if purpose == "signup" and existing:
            return jsonify({"error": "Email is already registered. Please login."}), 409
        if purpose == "reset" and not existing:
            return jsonify({"error": "Account not found for this email."}), 404

        otp_code = f"{secrets.randbelow(1000000):06d}"
        token = secrets.token_urlsafe(24)
        salt = secrets.token_hex(8)
        code_hash = sha256(f"{salt}:{otp_code}")
        # store salt inside hash field so we can verify (salt:hash)
        stored_hash = f"{salt}:{code_hash}"
        expires_at = dt_to_sql(now_utc() + timedelta(minutes=10))

        with db() as conn:
            # Invalidate older unused OTPs for the same email/purpose.
            conn.execute(
                "UPDATE email_otps SET used_at = datetime('now') WHERE email = ? AND purpose = ? AND used_at IS NULL;",
                (email, purpose),
            )
            conn.execute(
                """
                INSERT INTO email_otps (email, purpose, code_hash, token, expires_at)
                VALUES (?, ?, ?, ?, ?);
                """,
                (email, purpose, stored_hash, token, expires_at),
            )

        subject = "Your Mazon verification code"
        action = "create your account" if purpose == "signup" else "reset your password"
        body = f"Your OTP to {action} is: {otp_code}\n\nThis code expires in 10 minutes."
        sent = send_email(email, subject, body)

        resp = {"ok": True, "sent": sent, "token": token}
        if not sent:
            # Dev-friendly: if SMTP not configured, return the OTP so you can demo locally.
            resp["dev_otp"] = otp_code
        return jsonify(resp)

    @app.post("/api/auth/verify-otp")
    def verify_otp():
        data = request.get_json(force=True, silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        purpose = (data.get("purpose") or "signup").strip().lower()
        token = (data.get("token") or "").strip()
        code = (data.get("code") or "").strip()
        if not email or not token or not code:
            return jsonify({"error": "email, token and code are required."}), 400

        with db() as conn:
            row = conn.execute(
                """
                SELECT * FROM email_otps
                WHERE email = ? AND purpose = ? AND token = ?
                ORDER BY id DESC
                LIMIT 1;
                """,
                (email, purpose, token),
            ).fetchone()
            if not row:
                return jsonify({"error": "OTP not found. Request a new code."}), 404
            if row["used_at"]:
                return jsonify({"error": "OTP already used. Request a new code."}), 400

            # Expiry
            expires = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            if now_utc() > expires:
                return jsonify({"error": "OTP expired. Request a new code."}), 400

            salt, stored = (row["code_hash"] or "").split(":", 1)
            ok = sha256(f"{salt}:{code}") == stored
            attempts = int(row["attempts"] or 0) + 1
            conn.execute("UPDATE email_otps SET attempts = ? WHERE id = ?;", (attempts, row["id"]))
            if not ok:
                return jsonify({"error": "Invalid OTP code."}), 400

            # Mark used; keep token for final signup validation.
            conn.execute("UPDATE email_otps SET used_at = datetime('now') WHERE id = ?;", (row["id"],))

        return jsonify({"ok": True})

    @app.post("/api/auth/signup")
    def signup():
        data = request.get_json(force=True, silent=True) or {}
        name = (data.get("name") or "").strip()
        email = (data.get("email") or "").strip().lower()
        password = (data.get("password") or "").strip()
        otp_token = (data.get("otp_token") or "").strip()
        otp_code = (data.get("otp_code") or "").strip()

        if not name or not email or not password:
            return jsonify({"error": "Name, email, and password are required."}), 400
        if len(password) < 6:
            return jsonify({"error": "Password must be at least 6 characters."}), 400

        # OTP is required for signup.
        if not otp_token or not otp_code:
            return jsonify({"error": "OTP is required for signup. Click Send OTP and verify."}), 400
        with db() as conn:
            row = conn.execute(
                """
                SELECT * FROM email_otps
                WHERE email = ? AND purpose = 'signup' AND token = ?
                ORDER BY id DESC
                LIMIT 1;
                """,
                (email, otp_token),
            ).fetchone()
            if not row:
                return jsonify({"error": "OTP token not found. Request a new code."}), 404
            expires = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            if now_utc() > expires:
                return jsonify({"error": "OTP expired. Request a new code."}), 400
            if not row["used_at"]:
                return jsonify({"error": "OTP not verified yet. Verify the code first."}), 400
            salt, stored = (row["code_hash"] or "").split(":", 1)
            if sha256(f"{salt}:{otp_code}") != stored:
                return jsonify({"error": "OTP code mismatch."}), 400

        password_hash = generate_password_hash(password)
        try:
            with db() as conn:
                cur = conn.execute(
                    "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?);",
                    (name, email, password_hash),
                )
                user_id = cur.lastrowid
                conn.execute("INSERT OR IGNORE INTO carts (user_id) VALUES (?);", (user_id,))
        except sqlite3.IntegrityError:
            return jsonify({"error": "Email is already registered."}), 409

        session["user_id"] = user_id
        return jsonify({"ok": True, "user": {"id": user_id, "name": name, "email": email}})

    @app.post("/api/auth/login")
    def login():
        data = request.get_json(force=True, silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        password = (data.get("password") or "").strip()
        if not email or not password:
            return jsonify({"error": "Email and password are required."}), 400

        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email = ?;", (email,)).fetchone()
            if not user or not check_password_hash(user["password_hash"], password):
                return jsonify({"error": "Invalid email or password."}), 401
            conn.execute("INSERT OR IGNORE INTO carts (user_id) VALUES (?);", (user["id"],))

        session["user_id"] = int(user["id"])
        return jsonify(
            {"ok": True, "user": {"id": user["id"], "name": user["name"], "email": user["email"]}}
        )

    @app.post("/api/auth/reset-password")
    def reset_password():
        """
        Forgot password: verify OTP and set a new password.
        """
        data = request.get_json(force=True, silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        token = (data.get("otp_token") or "").strip()
        code = (data.get("otp_code") or "").strip()
        new_password = (data.get("new_password") or "").strip()

        if not email or not token or not code or not new_password:
            return jsonify({"error": "email, otp_token, otp_code and new_password are required."}), 400
        if len(new_password) < 6:
            return jsonify({"error": "Password must be at least 6 characters."}), 400

        with db() as conn:
            user = conn.execute("SELECT id FROM users WHERE email = ?;", (email,)).fetchone()
            if not user:
                return jsonify({"error": "Account not found for this email."}), 404

            row = conn.execute(
                """
                SELECT * FROM email_otps
                WHERE email = ? AND purpose = 'reset' AND token = ?
                ORDER BY id DESC
                LIMIT 1;
                """,
                (email, token),
            ).fetchone()
            if not row:
                return jsonify({"error": "OTP token not found. Request a new code."}), 404
            if row["used_at"]:
                return jsonify({"error": "OTP already used. Request a new code."}), 400
            expires = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            if now_utc() > expires:
                return jsonify({"error": "OTP expired. Request a new code."}), 400

            salt, stored = (row["code_hash"] or "").split(":", 1)
            if sha256(f"{salt}:{code}") != stored:
                attempts = int(row["attempts"] or 0) + 1
                conn.execute("UPDATE email_otps SET attempts = ? WHERE id = ?;", (attempts, row["id"]))
                return jsonify({"error": "Invalid OTP code."}), 400

            conn.execute("UPDATE email_otps SET used_at = datetime('now') WHERE id = ?;", (row["id"],))
            conn.execute(
                "UPDATE users SET password_hash = ? WHERE email = ?;",
                (generate_password_hash(new_password), email),
            )

        return jsonify({"ok": True})

    @app.post("/api/auth/logout")
    def logout():
        session.pop("user_id", None)
        return jsonify({"ok": True})

    @app.get("/api/me")
    def me():
        user_id = session.get("user_id")
        if not user_id:
            return jsonify({"user": None})
        with db() as conn:
            user = conn.execute(
                "SELECT id, name, email, created_at FROM users WHERE id = ?;", (user_id,)
            ).fetchone()
        return jsonify({"user": dict(user) if user else None})

    # ---------- Catalog ----------
    @app.get("/api/categories")
    def categories():
        with db() as conn:
            rows = conn.execute("SELECT id, name, slug FROM categories ORDER BY name;").fetchall()
        return jsonify({"categories": [dict(r) for r in rows]})

    @app.get("/api/products")
    def products():
        category_slug = (request.args.get("category") or "").strip()
        q = (request.args.get("q") or "").strip().lower()
        sort = (request.args.get("sort") or "").strip()  # price-asc | price-desc | rating-desc

        sql = """
          SELECT p.*, c.slug AS category_slug, c.name AS category_name
          FROM products p
          JOIN categories c ON c.id = p.category_id
        """
        where = []
        params: list[Any] = []
        if category_slug:
            where.append("c.slug = ?")
            params.append(category_slug)
        if q:
            where.append("(lower(p.title) LIKE ? OR lower(p.description) LIKE ?)")
            params.extend([f"%{q}%", f"%{q}%"])
        if where:
            sql += " WHERE " + " AND ".join(where)

        if sort == "price-asc":
            sql += " ORDER BY p.price_cents ASC"
        elif sort == "price-desc":
            sql += " ORDER BY p.price_cents DESC"
        elif sort == "rating-desc":
            sql += " ORDER BY p.rating DESC, p.rating_count DESC"
        else:
            sql += " ORDER BY p.created_at DESC, p.id DESC"

        with db() as conn:
            rows = conn.execute(sql + ";", params).fetchall()
        return jsonify({"products": [dict(r) for r in rows]})

    @app.get("/api/products/<int:product_id>")
    def product_detail(product_id: int):
        with db() as conn:
            row = conn.execute(
                """
                SELECT p.*, c.slug AS category_slug, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                WHERE p.id = ?;
                """,
                (product_id,),
            ).fetchone()
        if not row:
            return jsonify({"error": "Product not found"}), 404
        return jsonify({"product": dict(row)})

    # ---------- Cart ----------
    @app.get("/api/cart")
    def get_cart():
        user_id = require_auth()
        with db() as conn:
            items = conn.execute(
                """
                SELECT ci.product_id, ci.quantity, p.title, p.price_cents, p.image_key, p.image_url, p.rating, p.rating_count
                FROM cart_items ci
                JOIN products p ON p.id = ci.product_id
                WHERE ci.user_id = ?
                ORDER BY p.title;
                """,
                (user_id,),
            ).fetchall()
        return jsonify({"items": [dict(r) for r in items]})

    @app.post("/api/cart/items")
    def add_to_cart():
        user_id = require_auth()
        data = request.get_json(force=True, silent=True) or {}
        product_id = int(data.get("product_id") or 0)
        quantity = int(data.get("quantity") or 1)
        if product_id <= 0:
            return jsonify({"error": "product_id is required"}), 400
        if quantity < 1:
            quantity = 1

        with db() as conn:
            # Prevent duplicates: if exists, increment quantity.
            existing = conn.execute(
                "SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?;",
                (user_id, product_id),
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE cart_items SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?;",
                    (quantity, user_id, product_id),
                )
            else:
                conn.execute(
                    "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?);",
                    (user_id, product_id, quantity),
                )
            conn.execute("UPDATE carts SET updated_at = datetime('now') WHERE user_id = ?;", (user_id,))
        return jsonify({"ok": True})

    @app.patch("/api/cart/items/<int:product_id>")
    def update_cart_item(product_id: int):
        user_id = require_auth()
        data = request.get_json(force=True, silent=True) or {}
        quantity = int(data.get("quantity") or 1)
        if quantity < 1:
            quantity = 1
        with db() as conn:
            conn.execute(
                "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?;",
                (quantity, user_id, product_id),
            )
            conn.execute("UPDATE carts SET updated_at = datetime('now') WHERE user_id = ?;", (user_id,))
        return jsonify({"ok": True})

    @app.delete("/api/cart/items/<int:product_id>")
    def remove_cart_item(product_id: int):
        user_id = require_auth()
        with db() as conn:
            conn.execute(
                "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?;",
                (user_id, product_id),
            )
            conn.execute("UPDATE carts SET updated_at = datetime('now') WHERE user_id = ?;", (user_id,))
        return jsonify({"ok": True})

    # ---------- Checkout / Orders ----------
    @app.post("/api/checkout")
    def checkout():
        user_id = require_auth()
        data = request.get_json(force=True, silent=True) or {}
        shipping_name = (data.get("shipping_name") or "").strip()
        shipping_address = (data.get("shipping_address") or "").strip()
        payment_method = (data.get("payment_method") or "Card").strip()
        if not shipping_name or not shipping_address:
            return jsonify({"error": "Shipping name and address are required."}), 400

        with db() as conn:
            items = conn.execute(
                """
                SELECT ci.product_id, ci.quantity, p.title, p.price_cents
                FROM cart_items ci
                JOIN products p ON p.id = ci.product_id
                WHERE ci.user_id = ?;
                """,
                (user_id,),
            ).fetchall()
            if not items:
                return jsonify({"error": "Cart is empty."}), 400

            total_cents = sum(int(r["price_cents"]) * int(r["quantity"]) for r in items)
            cur = conn.execute(
                """
                INSERT INTO orders (user_id, total_cents, shipping_name, shipping_address, payment_method)
                VALUES (?, ?, ?, ?, ?);
                """,
                (user_id, total_cents, shipping_name, shipping_address, payment_method),
            )
            order_id = int(cur.lastrowid)
            conn.executemany(
                """
                INSERT INTO order_items (order_id, product_id, title, price_cents, quantity)
                VALUES (?, ?, ?, ?, ?);
                """,
                [(order_id, r["product_id"], r["title"], r["price_cents"], r["quantity"]) for r in items],
            )
            conn.execute("DELETE FROM cart_items WHERE user_id = ?;", (user_id,))
            conn.execute("UPDATE carts SET updated_at = datetime('now') WHERE user_id = ?;", (user_id,))
        return jsonify({"ok": True, "order_id": order_id})

    @app.get("/api/orders")
    def orders():
        user_id = require_auth()
        with db() as conn:
            orders_rows = conn.execute(
                """
                SELECT id, total_cents, placed_at, status, shipping_name, shipping_address, payment_method
                FROM orders
                WHERE user_id = ?
                ORDER BY placed_at DESC, id DESC;
                """,
                (user_id,),
            ).fetchall()
            orders_list = []
            for o in orders_rows:
                items = conn.execute(
                    """
                    SELECT product_id, title, price_cents, quantity
                    FROM order_items
                    WHERE order_id = ?
                    ORDER BY title;
                    """,
                    (o["id"],),
                ).fetchall()
                orders_list.append({**dict(o), "items": [dict(i) for i in items]})
        return jsonify({"orders": orders_list})

    # ---------- Assets ----------
    @app.get("/assets/img/<slug>.svg")
    def category_svg(slug: str):
        # Very lightweight image placeholder (keeps demo self-contained/offline).
        text = (request.args.get("text") or "Product")[:40]
        safe = text.replace("&", "and").replace("<", "").replace(">", "")
        colors = {
            "electronics": ("#0ea5e9", "#0b1220"),
            "fashion": ("#f97316", "#1f0f07"),
            "home-kitchen": ("#22c55e", "#071a0f"),
        }
        c1, c2 = colors.get(slug, ("#a78bfa", "#0b1220"))
        svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{c1}"/>
      <stop offset="1" stop-color="{c2}"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#g)"/>
  <rect x="40" y="40" width="720" height="520" rx="24" fill="rgba(255,255,255,0.08)"/>
  <text x="80" y="310" font-family="Arial, Helvetica, sans-serif" font-size="44" fill="white">{safe}</text>
  <text x="80" y="360" font-family="Arial, Helvetica, sans-serif" font-size="20" fill="rgba(255,255,255,0.8)">Amazon-style demo</text>
</svg>"""
        return app.response_class(svg, mimetype="image/svg+xml")

    # ---------- Frontend ----------
    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/<path:path>")
    def static_proxy(path: str):
        # SPA routing fallback: serve index.html for unknown routes.
        static_path = ROOT / "static" / path
        if static_path.exists() and static_path.is_file():
            return send_from_directory(app.static_folder, path)
        return redirect("/")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)

