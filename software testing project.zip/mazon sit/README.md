## Mazon — Amazon Clone (Demo)

Professional, demo-ready Amazon-style clone using:
- **Frontend**: HTML + CSS + Vanilla JavaScript (responsive)
- **Backend**: **Flask** (Python)
- **Database**: **SQLite** (seeded with categories + products)

### Features
- **3 product categories** with **30 products** (10 per category)
- Home page with category browsing
- Category product listing with **search** and **sorting**
- Product details page (price, image, description, ratings)
- Add to cart + prevent duplicates
- Cart page with **quantity control**, remove, dynamic total
- Dummy checkout that creates an order in SQLite
- Signup/Login + Profile + **Order history**
- **Email OTP verification for signup** (SMTP supported; dev fallback shows OTP if SMTP not configured)
- Forgot password: **OTP email + reset password**
- Cart is saved per user (server-side); guest cart uses localStorage

### Run (Windows / PowerShell)

Install dependencies:

```bash
py -m pip install -r requirements.txt
```

Create/seed the database:

```bash
py db\seed.py
```

This also generates deterministic product images at:
- `static/product-images/*.svg`

### Add real product photos (recommended)
Put your real images here:
- `static/product-photos/`

Naming rule (must match the product `image_key`):
- Example: `static/product-photos/fashion-womens-handbag.jpg`

If a real photo is missing, the UI automatically falls back to the generated SVG in `static/product-images/`.

Start the server:

```bash
py app.py
```

Open:
- `http://127.0.0.1:5000/`

### (Optional) Configure real OTP emails (SMTP)
Set these environment variables before starting `app.py`:
- `SMTP_HOST` (example: `smtp.gmail.com`)
- `SMTP_PORT` (example: `587`)
- `SMTP_SECURITY` (`starttls` default | `ssl` | `none`)
- `SMTP_USER` (your email / SMTP username)
- `SMTP_PASS` (your app password)
- `SMTP_FROM` (from address, usually same as user)

If SMTP is not configured, the app returns `dev_otp` in the OTP API response so you can demo locally.

Quick check (after server starts):
- Open `http://127.0.0.1:5000/api/auth/smtp-status`

### Project Structure
- `app.py`: Flask server + API routes
- `db/schema.sql`: SQLite schema
- `db/seed.py`: seeds categories + products
- `db/amazon_clone.sqlite`: generated database file
- `static/index.html`: UI shell
- `static/styles.css`: Amazon-like styling
- `static/app.js`: SPA routing + cart/auth/search logic

