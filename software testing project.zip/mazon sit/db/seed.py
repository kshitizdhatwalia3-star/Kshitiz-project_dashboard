"""
Seed script: creates schema and inserts demo categories + products.

Run:
  python db/seed.py
"""

from __future__ import annotations

import pathlib
import sqlite3


ROOT = pathlib.Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "db" / "amazon_clone.sqlite"
SCHEMA_PATH = ROOT / "db" / "schema.sql"
PRODUCT_IMG_DIR = ROOT / "static" / "product-images"


def _safe_key(s: str) -> str:
    return (
        (s or "")
        .lower()
        .replace("&", "and")
        .replace("'", "")
        .replace('"', "")
        .replace("  ", " ")
        .strip()
        .replace(" ", "-")
    )


def _write_product_svg(path: pathlib.Path, title: str, subtitle: str, emoji: str, c1: str, c2: str) -> None:
    """
    Creates a clean, deterministic SVG "product photo" (demo-friendly, no external downloads).
    """
    # Basic escaping (enough for our seeded strings)
    def esc(x: str) -> str:
        return (x or "").replace("&", "and").replace("<", "").replace(">", "")

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{c1}"/>
      <stop offset="1" stop-color="{c2}"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="14" stdDeviation="18" flood-color="rgba(0,0,0,0.35)"/>
    </filter>
  </defs>
  <rect width="100%" height="100%" fill="url(#g)"/>
  <g filter="url(#shadow)">
    <rect x="54" y="54" width="692" height="492" rx="28" fill="rgba(255,255,255,0.10)" stroke="rgba(255,255,255,0.16)"/>
  </g>
  <text x="96" y="200" font-family="Segoe UI Emoji, Apple Color Emoji, Noto Color Emoji, Arial" font-size="112">{esc(emoji)}</text>
  <text x="96" y="310" font-family="Arial, Helvetica, sans-serif" font-size="46" font-weight="800" fill="white">{esc(title)}</text>
  <text x="96" y="356" font-family="Arial, Helvetica, sans-serif" font-size="20" fill="rgba(255,255,255,0.85)">{esc(subtitle)}</text>
  <text x="96" y="520" font-family="Arial, Helvetica, sans-serif" font-size="16" fill="rgba(255,255,255,0.65)">Mazon • Demo product image</text>
</svg>"""
    path.write_text(svg, encoding="utf-8")


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def run_schema(conn: sqlite3.Connection) -> None:
    schema_sql = SCHEMA_PATH.read_text(encoding="utf-8")
    conn.executescript(schema_sql)
    # Lightweight migration for existing DBs: add products.image_key if missing.
    cols = [r["name"] for r in conn.execute("PRAGMA table_info(products);").fetchall()]
    if "image_key" not in cols:
        conn.execute("ALTER TABLE products ADD COLUMN image_key TEXT NOT NULL DEFAULT '';")
    conn.commit()


def seed(conn: sqlite3.Connection) -> None:
    categories = [
        ("Electronics", "electronics"),
        ("Fashion", "fashion"),
        ("Home & Kitchen", "home-kitchen"),
    ]

    conn.executemany(
        "INSERT OR IGNORE INTO categories (name, slug) VALUES (?, ?);",
        categories,
    )

    cat_id = {
        row["slug"]: row["id"]
        for row in conn.execute("SELECT id, slug FROM categories;").fetchall()
    }

    # Generate deterministic per-product SVG images so every product always shows the same (non-random) image.
    products = []

    def add(slug: str, title: str, price_cents: int, rating: float, rating_count: int, desc: str):
        seed_key = _safe_key(slug + "-" + title)
        PRODUCT_IMG_DIR.mkdir(parents=True, exist_ok=True)

        # Simple icon + palette mapping (keeps images product-relevant and consistent like a catalog).
        palette = {
            "electronics": ("#0ea5e9", "#0b1220"),
            "fashion": ("#f97316", "#1f0f07"),
            "home-kitchen": ("#22c55e", "#071a0f"),
        }
        icon = "🛍️"
        if "headphone" in title.lower() or "earbud" in title.lower():
            icon = "🎧"
        elif "speaker" in title.lower():
            icon = "🔊"
        elif "watch" in title.lower():
            icon = "⌚"
        elif "charger" in title.lower():
            icon = "🔌"
        elif "keyboard" in title.lower():
            icon = "⌨️"
        elif "webcam" in title.lower():
            icon = "📷"
        elif "ssd" in title.lower():
            icon = "💾"
        elif "monitor" in title.lower():
            icon = "🖥️"
        elif "stream" in title.lower():
            icon = "📺"
        elif "shirt" in title.lower() or "hoodie" in title.lower():
            icon = "👕"
        elif "sneaker" in title.lower():
            icon = "👟"
        elif "wallet" in title.lower():
            icon = "👛"
        elif "sunglass" in title.lower():
            icon = "🕶️"
        elif "handbag" in title.lower():
            icon = "👜"
        elif "shorts" in title.lower():
            icon = "🩳"
        elif "cap" in title.lower():
            icon = "🧢"
        elif "scarf" in title.lower():
            icon = "🧣"
        elif "pan" in title.lower():
            icon = "🍳"
        elif "kettle" in title.lower():
            icon = "🫖"
        elif "knife" in title.lower():
            icon = "🔪"
        elif "flask" in title.lower():
            icon = "🥤"
        elif "bedsheet" in title.lower():
            icon = "🛏️"
        elif "lamp" in title.lower():
            icon = "💡"
        elif "container" in title.lower():
            icon = "🧺"
        elif "mug" in title.lower():
            icon = "☕"
        elif "mat" in title.lower():
            icon = "🚪"
        elif "diffuser" in title.lower():
            icon = "🌫️"

        c1, c2 = palette.get(slug, ("#a78bfa", "#0b1220"))
        svg_path = PRODUCT_IMG_DIR / f"{seed_key}.svg"
        _write_product_svg(svg_path, title=title, subtitle=slug.replace("-", " ").title(), emoji=icon, c1=c1, c2=c2)

        products.append(
            (
                cat_id[slug],
                title,
                price_cents,
                seed_key,
                f"/product-photos/{seed_key}.jpg",
                desc,
                rating,
                rating_count,
            )
        )

    # Electronics (10)
    add("electronics", "Wireless Headphones", 4999, 4.6, 2451, "Comfortable over-ear headphones with rich bass and 30h battery.")
    add("electronics", "Bluetooth Speaker", 2999, 4.5, 1870, "Portable speaker with deep sound, splash resistance, and USB-C charging.")
    add("electronics", "Smart Watch", 6999, 4.3, 3210, "Fitness tracking, heart rate, sleep monitoring, and notification support.")
    add("electronics", "USB-C Fast Charger", 1299, 4.7, 8450, "65W fast charger for phones and laptops with smart power delivery.")
    add("electronics", "Mechanical Keyboard", 5999, 4.8, 1620, "Tactile switches, RGB lighting, and sturdy aluminum frame.")
    add("electronics", "1080p Webcam", 3999, 4.4, 2140, "Crisp video calls with low-light correction and dual microphones.")
    add("electronics", "Noise Cancelling Earbuds", 7999, 4.5, 2765, "Active noise cancellation with transparency mode and wireless charging.")
    add("electronics", "Portable SSD 1TB", 8999, 4.8, 4980, "High-speed external SSD for backups and editing on the go.")
    add("electronics", "27-inch Monitor", 14999, 4.6, 1125, "IPS display, thin bezels, and vivid colors for work and entertainment.")
    add("electronics", "Streaming Stick", 3499, 4.4, 9050, "Fast streaming with voice remote and support for popular apps.")

    # Fashion (10)
    add("fashion", "Men's Casual Shirt", 1899, 4.2, 980, "Breathable cotton shirt with a modern fit for everyday wear.")
    add("fashion", "Women's Sneakers", 2499, 4.6, 2310, "Lightweight sneakers with cushioned sole for all-day comfort.")
    add("fashion", "Leather Wallet", 999, 4.5, 1540, "Slim genuine leather wallet with RFID protection.")
    add("fashion", "Classic Wrist Watch", 4599, 4.4, 720, "Minimal design with durable strap and water resistance.")
    add("fashion", "Unisex Sunglasses", 1299, 4.3, 1900, "UV400 protection with a timeless frame for any outfit.")
    add("fashion", "Women's Handbag", 3299, 4.5, 860, "Spacious handbag with multiple compartments and premium finish.")
    add("fashion", "Men's Running Shorts", 1199, 4.2, 1340, "Quick-dry fabric with breathable mesh panels and secure pockets.")
    add("fashion", "Hoodie Sweatshirt", 2199, 4.6, 2750, "Soft fleece hoodie with a cozy fit and strong stitching.")
    add("fashion", "Sports Cap", 799, 4.4, 4100, "Adjustable cap with sweat-wicking band for outdoor activities.")
    add("fashion", "Women's Winter Scarf", 899, 4.7, 2250, "Warm, soft scarf with elegant texture and versatile styling.")

    # Home & Kitchen (10)
    add("home-kitchen", "Non-stick Frying Pan", 1999, 4.5, 4200, "Even heat distribution with durable non-stick coating.")
    add("home-kitchen", "Stainless Steel Kettle", 1799, 4.4, 1650, "Fast boiling kettle with auto shut-off and ergonomic handle.")
    add("home-kitchen", "Knife Set (6 pcs)", 2599, 4.6, 1890, "Sharp blades with comfortable grip and sleek storage stand.")
    add("home-kitchen", "Vacuum Flask 1L", 1499, 4.7, 5100, "Keeps beverages hot/cold for hours with leak-proof lid.")
    add("home-kitchen", "Microfiber Bedsheet", 1299, 4.3, 2700, "Soft, wrinkle-resistant bedsheet set for a clean modern look.")
    add("home-kitchen", "LED Desk Lamp", 1599, 4.5, 3100, "Adjustable brightness, eye-care lighting, and USB charging port.")
    add("home-kitchen", "Storage Containers (Set)", 1399, 4.4, 2400, "Airtight containers ideal for pantry organization and leftovers.")
    add("home-kitchen", "Coffee Mug Set", 999, 4.6, 2800, "Ceramic mugs with comfortable handle and minimalist design.")
    add("home-kitchen", "Door Mat", 699, 4.2, 1500, "Anti-slip, easy-to-clean mat for a welcoming entrance.")
    add("home-kitchen", "Aroma Diffuser", 2199, 4.5, 1950, "Quiet diffuser with soft light modes for relaxing ambience.")

    conn.executemany(
        """
        INSERT INTO products
          (category_id, title, price_cents, image_key, image_url, description, rating, rating_count)
        VALUES
          (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        products,
    )
    conn.commit()


def main() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as conn:
        run_schema(conn)
        # Clear old products (keep users/orders if any)
        conn.execute("DELETE FROM products;")
        seed(conn)
    print(f"Seeded database at: {DB_PATH}")


if __name__ == "__main__":
    main()

